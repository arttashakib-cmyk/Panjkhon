# -*- coding: utf-8 -*-
"""ساخت فایل‌های واژه‌ی بازی.
ورودی: tools/clues_*.txt  (هر خط: کلمه=سرنخ)
خروجی: app/src/main/assets/{answers_levels,answers_extra,guesses}.txt
"""
import random, math, sys, os, glob, collections
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ALPHA = set("آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی")
LEVELS = 1000
RARE = set(open(os.path.join(HERE, "rare.txt"), encoding="utf-8").read().split())

pairs = {}
for f in sorted(glob.glob(os.path.join(HERE, "clues_*.txt"))):
    for line in open(f, encoding="utf-8"):
        line = line.strip()
        if "=" not in line: continue
        w, c = line.split("=", 1)
        w, c = w.strip(), c.strip()
        if len(w) == 5 and all(ch in ALPHA for ch in w) and w not in pairs and w not in c and "|" not in c:
            pairs[w] = c
words = list(pairs)
print("answer words with clue:", len(words))
if len(words) < LEVELS:
    print("NOT ENOUGH"); sys.exit(1)

rng = random.Random(20261118)
rng.shuffle(words)
levels = words[:LEVELS]
extra = words[LEVELS:]

freq = collections.Counter(c for w in words for c in set(w))
total = sum(freq.values())
rare = set("ظضثذژغص")
def score(w):
    s = sum(-math.log(freq[c] / total) for c in set(w))
    s += 1.5 * (len(w) - len(set(w)))
    s += 1.2 * sum(1 for c in w if c in rare)
    return s + rng.gauss(0, 0.9)
levels.sort(key=score)

# ---------- فرهنگ حدس (واژه‌های مجاز) ----------
STEM3 = "رفت گفت دید کرد برد مرد داد آمد بود زاد خفت بست شست جست گشت کشت رست خست زد شد دانست".split()
STEM4 = "خورد شکست گرفت نوشت ماند ساخت باخت پرید دوید خرید کشید رسید شنید چشید دوخت سوخت بافت یافت تافت کاشت داشت گذشت نشست پخت ریخت گفتم شمرد سپرد فشرد نمود ستود کاست آراست".split()
NOUN3 = "دست مرد زن پسر کار روز ماه سال کوه رود دل راه درد گوش سنگ خاک باد آتش? نان آب گل شاخ برگ ریش لب مو پا چای نام جان تن رخ بام در دیو پری ابر مه برف سیب گاو گوسفند? شیر خرس سگ اسب موش مار کلاغ? خروس? آهو بز قوچ یار دوست? جام کاسه? ساز نی دف تار سنج? کتاب? نقش رنگ خط ورق پول سکه زر سیم مس روی آهن چوب پشت رو سو سر یال دم شاخ بال پر منقار? چنگ پنجه".replace("?", "").split()
NOUN4 = "کتاب خانه شهر دریا جنگل بازار مدرسه? میوه سبزی باران کوچه خیابان? ماشین? دوست مادر پدر دختر نوزاد همسر رفیق معلم استاد دکتر پزشک وکیل قاضی نانوا قصاب بقال عطار نقاش شاعر دشمن مهمان خیمه چادر لباس کفش کلاه جوراب عینک ساعت تلفن آینه پرده قالی گلیم بالش لحاف حوله شانه قاشق چنگال کارد بشقاب لیوان کتری قوری سینی جارو چراغ لامپ پریز کلید قفل طناب چکش دفتر مداد کاغذ پاکت قیچی تخته گچ خورش کباب برنج پلو خیار هویج پیاز لیمو انار انگور شلیل خرما پسته فندق گردو کشمش عسل شکر نمک فلفل قهوه شربت حلوا کیک کتلت املت حلیم ترشی مربا آجیل سمنو شلغم گاری جاده پل تونل مسیر سفر بلیط مقصد قطار کشتی قایق صبح ظهر عصر شامگاه نیمه شبانه فردا امشب هفته لحظه فصل بهار تابستان? زمستان? پاییز خورشید? ماه ستاره آسمان زمین کوهی دشتی رودی دریاچه? بیشه نهال برگ ریشه شاخه غنچه گلبرگ سنبل نعنا شوید کاهو ذرت نخود عدس گندم جو بلبل طوطی کلاغ جغد سگ گربه اسب شتر الاغ گاو بره بزغاله گرگ شیر ببر پلنگ فیل میمون ماهی نهنگ کوسه خرچنگ مورچه زنبور مگس پشه کرم مار مارمولک عقاب شاهین قناری کبوتر گنجشک خروس مرغ".replace("?", "").split()
nouns3 = [w for w in NOUN3 if len(w) == 3]
nouns4 = [w for w in NOUN4 if len(w) == 4]
derived = set()
for w in nouns3:
    derived.add(w + "ها"); derived.add(w + "ان")
for w in nouns4:
    derived.add(w + "ی")
    for suf in "مت": derived.add(w + suf)
    derived.add(w + "ش")
for s in STEM3:
    if len(s) == 3:
        for e in ("ند", "ید", "یم"): derived.add(s + e)
for s in STEM4:
    if len(s) == 4:
        for e in "یم": derived.add(s + e)
        derived.add(s + "ن")
    if len(s) == 3:
        for e in ("ند", "ید", "یم"): derived.add(s + e)
EXTRA_GUESS = """
خوردن نوشتن شنیدن گرفتن ماندن رسیدن پریدن دویدن نشستن دوختن ساختن بافتن کاشتن شکستن خریدن آفریدن
آشفته آلوده آهنین آبکی آبیاری آتشی آزادانه آشنای آموخته نوشته پدیده پدیدار پیروان پیشوا پیشگو
عصبی عاطفی عاشقی دلبری دلاور خوانا خوانده کارتن کارمند کارآمد سکوی سکوت سکونت منشور منشی منتظر
اشتیاق اشتهار اشتغال بازرگان بازیکن چاقوی چاپگر مسجدی مسجد
""".split()
# فرهنگ اصلی واژه‌های مجاز: فایل ~۱۰٫۶ هزار کلمه‌ی پنج‌حرفی (tools/dictionary_5.txt)
DICT = set(w.strip() for w in open(os.path.join(HERE, "dictionary_5.txt"), encoding="utf-8") if w.strip())
guess = {w for w in (DICT | set(EXTRA_GUESS)) if len(w) == 5 and all(c in ALPHA for c in w)}
guess -= set(pairs)

os.makedirs(os.path.join(ROOT, "app/src/main/assets"), exist_ok=True)
def put(name, lines):
    open(os.path.join(ROOT, "app/src/main/assets", name), "w", encoding="utf-8").write("\n".join(lines) + "\n")
def line(w):
    return f"{w}|{pairs[w]}" + ("|r" if w in RARE else "")
put("answers_levels.txt", [line(w) for w in levels])
put("answers_extra.txt", [line(w) for w in extra])
put("guesses.txt", sorted(guess))
print("levels", len(levels), "extra", len(extra), "guess-only", len(guess))
print("easiest:", levels[:8]); print("hardest:", levels[-8:])
