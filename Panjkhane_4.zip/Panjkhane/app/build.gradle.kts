plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.panjkhane.game"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.panjkhane.game"
        minSdk = 24
        targetSdk = 34
        // کد نسخه با زمان ساخت (دقیقه) بالا می‌رود تا هر نسخه‌ی تازه روی نسخه‌ی قبلی نصب شود
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.0"
    }

    signingConfigs {
        create("release") {
            // کلید ثابت پروژه: همه‌ی نسخه‌ها با همین کلید امضا می‌شوند تا آپدیت روی نسخه‌ی قبلی ممکن باشد
            storeFile = file("keystore/panjkhane.jks")
            storePassword = "8WkDBuG06WSvEYOTJsWh"
            keyAlias = "panjkhane"
            keyPassword = "8WkDBuG06WSvEYOTJsWh"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.foundation)
    implementation(libs.compose.material3)
    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)
    implementation(libs.datastore.preferences)
    coreLibraryDesugaring(libs.desugar)
}
