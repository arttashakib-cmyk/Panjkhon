package com.panjkhane.game.game

import com.panjkhane.game.data.GameResult
import com.panjkhane.game.data.LevelResult

data class Badge(val icon: String, val title: String, val desc: String, val have: Int, val need: Int) {
    val unlocked: Boolean get() = have >= need
}

/** نشان‌ها از روی نتیجه‌ها محاسبه می‌شوند؛ چیزی جدا ذخیره نمی‌شود. */
fun computeBadges(levels: List<LevelResult>, all: List<GameResult>): List<Badge> {
    val done = levels.size
    val threeStar = levels.count { it.guesses <= 2 }
    val wins = all.count { it.won }
    val oneShot = if (all.any { it.won && it.guesses == 1 }) 1 else 0
    val lastChance = if (all.any { it.won && it.guesses == 6 }) 1 else 0
    val dailyBest = computeStats(all.filter { it.mode == "daily" }, true, 0).best
    val infiniteWins = all.count { it.mode == "infinite" && it.won }
    return listOf(
        Badge("🌱", "اولین برد", "اولین کلمه‌ات را پیدا کن", wins, 1),
        Badge("🏁", "ده مرحله", "۱۰ مرحله را تمام کن", done, 10),
        Badge("🥉", "پنجاه مرحله", "۵۰ مرحله را تمام کن", done, 50),
        Badge("🥈", "صد مرحله", "۱۰۰ مرحله را تمام کن", done, 100),
        Badge("🥇", "دویست‌وپنجاه مرحله", "۲۵۰ مرحله را تمام کن", done, 250),
        Badge("🏆", "پانصد مرحله", "۵۰۰ مرحله را تمام کن", done, 500),
        Badge("👑", "استاد کلمه", "هر ۱۰۰۰ مرحله را تمام کن", done, 1000),
        Badge("🎯", "یک‌ضرب", "کلمه را با همان حدس اول پیدا کن", oneShot, 1),
        Badge("😅", "لحظه‌ی آخر", "با حدس ششم ببر", lastChance, 1),
        Badge("⭐", "ستاره‌باز", "در ۲۵ مرحله سه ستاره بگیر", threeStar, 25),
        Badge("🔥", "سه روز پیاپی", "سه روز پشت سر هم چالش روزانه را ببر", dailyBest, 3),
        Badge("🌟", "هفته‌ی طلایی", "هفت روز پیاپی چالش روزانه را ببر", dailyBest, 7),
        Badge("💎", "یک ماه پشتکار", "سی روز پیاپی چالش روزانه را ببر", dailyBest, 30),
        Badge("♾️", "بی‌پایان‌باز", "۵۰ کلمه را در حالت بی‌پایان پیدا کن", infiniteWins, 50)
    )
}
