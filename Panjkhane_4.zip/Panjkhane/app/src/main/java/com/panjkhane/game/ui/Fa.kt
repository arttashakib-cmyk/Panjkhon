package com.panjkhane.game.ui

fun String.faDigits(): String = map { if (it in '0'..'9') '\u06F0' + (it - '0') else it }.joinToString("")

fun Int.fa(): String = toString().faDigits()

/** ستاره‌ی هر مرحله بر اساس تعداد حدس */
fun starsFor(guesses: Int): Int = when {
    guesses <= 2 -> 3
    guesses <= 4 -> 2
    else -> 1
}
