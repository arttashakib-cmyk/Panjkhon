package com.panjkhane.game.ui

import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper

/** افکت‌های صوتیِ کوتاه بدون نیاز به فایل صوتی */
object Sfx {
    fun win() = beep(ToneGenerator.TONE_PROP_ACK, 220)
    fun lose() = beep(ToneGenerator.TONE_PROP_NACK, 260)
    fun invalid() = beep(ToneGenerator.TONE_PROP_NACK, 120)

    private fun beep(tone: Int, ms: Int) {
        try {
            val g = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
            g.startTone(tone, ms)
            Handler(Looper.getMainLooper()).postDelayed({ g.release() }, ms + 150L)
        } catch (_: Exception) {
        }
    }
}
