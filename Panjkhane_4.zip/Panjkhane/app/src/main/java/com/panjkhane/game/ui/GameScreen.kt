package com.panjkhane.game.ui

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.panjkhane.game.PanjkhaneApp
import com.panjkhane.game.data.Mode
import com.panjkhane.game.data.Settings
import com.panjkhane.game.engine.Persian
import com.panjkhane.game.engine.TileState
import com.panjkhane.game.game.GameViewModel
import com.panjkhane.game.game.Status
import kotlinx.coroutines.delay

private fun shareText(title: String, status: Status, guesses: List<String>, answer: String): String {
    val score = if (status == Status.WON) guesses.size.fa() else "✗"
    val grid = guesses.joinToString("\n") { g ->
        Persian.evaluate(g, answer).joinToString("") {
            when (it) { TileState.CORRECT -> "🟩"; TileState.PRESENT -> "🟨"; TileState.ABSENT -> "⬛" }
        }
    }
    return "پنج‌خانه | $title | $score/${Persian.MAX_GUESSES.fa()}\n$grid"
}

@Composable
fun GameScreen(mode: Mode, slot: Int, nav: NavController, st: Settings) {
    val app = LocalContext.current.applicationContext as PanjkhaneApp
    val vm: GameViewModel = viewModel(key = "${mode.id}-$slot", factory = GameViewModel.factory(app, mode, slot))
    val ui by vm.ui.collectAsState()
    val haptic = LocalHapticFeedback.current
    val title = when (mode) {
        Mode.LEVEL -> "مرحله‌ی ${slot.fa()}"
        Mode.DAILY -> "چالش روزانه"
        Mode.INFINITE -> "حالت بی‌پایان"
    }
    val clue = remember(ui.answer) { if (ui.answer.isEmpty()) null else app.repo.lex.clueFor(ui.answer) }
    var showClue by remember { mutableStateOf(false) }
    LaunchedEffect(ui.message) { if (ui.message != null && !ui.readOnly) { delay(1800); vm.clearMessage() } }
    LaunchedEffect(ui.showResult) {
        if (ui.showResult) {
            if (st.haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            if (st.sound) { if (ui.status == Status.WON) Sfx.win() else Sfx.lose() }
        }
    }
    LaunchedEffect(ui.shake) { if (ui.shake > 0 && st.sound) Sfx.invalid() }

    val celebrate = ui.status == Status.WON && !ui.readOnly && !ui.loading && ui.guesses.isNotEmpty() && ui.keyboardRows >= ui.guesses.size
    Box(Modifier.fillMaxSize()) {
    ScreenScaffold(title, onBack = { nav.popBackStack() }, actions = {
        if (clue != null && ui.status == Status.PLAYING && !ui.readOnly && !ui.loading) {
            TextButton(onClick = { showClue = true }) { Text("🔎 سرنخ", fontSize = 15.sp) }
        }
        if (st.hints && ui.status == Status.PLAYING && !ui.readOnly && !ui.loading) {
            TextButton(onClick = vm::hint, enabled = ui.hintsLeft > 0) { Text("💡 ${ui.hintsLeft.fa()}", fontSize = 16.sp) }
        }
    }) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp), contentAlignment = Alignment.Center) {
            val tile = minOf((maxWidth - 24.dp) / 5, (maxHeight - 30.dp) / 6, 64.dp)
            if (!ui.loading) Board(ui.guesses, ui.current, ui.answer, ui.hints, ui.animateRow, ui.shake, tile, st.animations, celebrateRow = if (celebrate) ui.guesses.size - 1 else -1)
        }
        Text(
            ui.message ?: "", modifier = Modifier.fillMaxWidth().heightIn(min = 40.dp).padding(horizontal = 16.dp),
            textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 14.sp
        )
        if (ui.status == Status.PLAYING && !ui.readOnly) {
            Keyboard(
                states = ui.keyStates,
                onKey = { c -> if (st.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); vm.type(c) },
                onDelete = { if (st.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); vm.delete() },
                onEnter = vm::submit
            )
        } else if (!ui.loading) {
            ResultActions(mode, slot, title, ui.status, ui.answer, ui.guesses, nav, vm)
        }
        Spacer(Modifier.navigationBarsPadding())
    }
    if (celebrate) Confetti()
    }

    if (showClue && clue != null) AlertDialog(
        onDismissRequest = { showClue = false },
        title = { Text("🔎 سرنخ") },
        text = { Text(clue, fontSize = 17.sp) },
        confirmButton = { TextButton(onClick = { showClue = false }) { Text("باشه") } }
    )

    if (ui.showResult) AlertDialog(
        onDismissRequest = { vm.dismissResult() },
        title = {
            val stars = if (ui.status == Status.WON && mode == Mode.LEVEL) "  " + "⭐".repeat(starsFor(ui.guesses.size)) else ""
            Text(if (ui.status == Status.WON) "آفرین! 🎉$stars" else "این بار نشد")
        },
        text = {
            Text(
                if (ui.status == Status.WON) "کلمه‌ی «${ui.answer}» را در ${ui.guesses.size.fa()} حدس پیدا کردی."
                else "کلمه‌ی درست «${ui.answer}» بود."
            )
        },
        confirmButton = { ResultActions(mode, slot, title, ui.status, ui.answer, ui.guesses, nav, vm, inDialog = true) }
    )
}

@Composable
private fun ResultActions(
    mode: Mode, slot: Int, title: String, status: Status, answer: String, guesses: List<String>,
    nav: NavController, vm: GameViewModel, inDialog: Boolean = false
) {
    val ctx = LocalContext.current
    val modifier = if (inDialog) Modifier else Modifier.fillMaxWidth().padding(16.dp)
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (!inDialog) Text(
            if (status == Status.WON) "کلمه: $answer — ${guesses.size.fa()} حدس" else "کلمه‌ی درست: $answer",
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold
        )
        when (mode) {
            Mode.LEVEL -> {
                if (status == Status.WON && slot < Persian.LEVELS) {
                    Button(onClick = { nav.popBackStack(); nav.navigate("game/level/${slot + 1}") }, modifier = Modifier.fillMaxWidth()) { Text("مرحله‌ی بعد") }
                }
                if (status == Status.LOST) Button(onClick = { vm.restart() }, modifier = Modifier.fillMaxWidth()) { Text("تلاش دوباره") }
            }
            Mode.INFINITE -> Button(onClick = { vm.restart() }, modifier = Modifier.fillMaxWidth()) { Text("کلمه‌ی بعدی") }
            Mode.DAILY -> {}
        }
        OutlinedButton(
            onClick = {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, shareText(title, status, guesses, answer))
                }
                ctx.startActivity(Intent.createChooser(send, null))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("اشتراک‌گذاری نتیجه") }
        OutlinedButton(onClick = { nav.popBackStack() }, modifier = Modifier.fillMaxWidth()) { Text("بازگشت") }
    }
}
