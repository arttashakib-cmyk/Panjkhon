package com.panjkhane.game.engine

import kotlin.random.Random

/**
 * ترتیب تصادفی مرحله‌ها برای هر بازیکن، به‌گونه‌ای که کلمه‌های شبیه هم پشت سر هم نیایند.
 * ۱۵۰ مرحله‌ی اول فقط از کلمه‌های رایج (نه نام خاص و نه کلمه‌ی سخت) انتخاب می‌شوند.
 * «شبیه» یعنی: پیشوند یا پسوند مشترک ۳ حرفی، ۳ حرف هم‌جایگاه، ۴ حرف مشترک، یا کلمه‌ی کلیدی مشترک در سرنخ
 * (مثلاً دو «شهر» یا دو «پرنده» پشت سر هم).
 */
object LevelOrder {
    private val STOP = setOf("مربوط", "برای", "وابسته", "کردن", "کسی", "چیزی", "همان", "بعد", "پیش", "مثل", "آنچه")
    private val SPLIT = Regex("[\\s،.؟!…:\\-]+")

    fun build(
        words: List<String>, clueOf: (String) -> String?, isHard: (String) -> Boolean, seed: Long,
        easyCount: Int = 150, window: Int = 4
    ): List<Int> {
        val n = words.size
        val tokens = List(n) { i ->
            (clueOf(words[i]) ?: "").split(SPLIT).filter { it.length >= 4 && it !in STOP }.toSet()
        }

        fun similar(a: Int, b: Int): Boolean {
            val x = words[a]; val y = words[b]
            var p = 0
            while (p < x.length && p < y.length && x[p] == y[p]) p++
            if (p >= 3) return true
            var s = 0
            while (s < x.length && s < y.length && x[x.length - 1 - s] == y[y.length - 1 - s]) s++
            if (s >= 3) return true
            var pos = 0
            for (i in 0 until minOf(x.length, y.length)) if (x[i] == y[i]) pos++
            if (pos >= 3) return true
            val cnt = HashMap<Char, Int>()
            for (c in x) cnt[c] = (cnt[c] ?: 0) + 1
            var common = 0
            for (c in y) { val k = cnt[c] ?: 0; if (k > 0) { common++; cnt[c] = k - 1 } }
            if (common >= 4) return true
            return tokens[a].any { it in tokens[b] }
        }

        val remaining = ArrayList((0 until n).toList().shuffled(Random(seed)))
        val result = ArrayList<Int>(n)
        while (remaining.isNotEmpty()) {
            val recent = result.takeLast(window)
            val needEasy = result.size < easyCount
            var pick = -1
            for (k in remaining.indices) {
                val cand = remaining[k]
                if (needEasy && isHard(words[cand])) continue
                if (recent.none { similar(it, cand) }) { pick = k; break }
            }
            if (pick == -1) {
                // اگر چاره‌ای نبود: در بخش آسان اولین کلمه‌ی آسان، وگرنه اولین مانده
                pick = if (needEasy) remaining.indexOfFirst { !isHard(words[it]) }.let { if (it >= 0) it else 0 } else 0
            }
            result.add(remaining.removeAt(pick))
        }
        return result
    }
}
