package com.panjkhane.game

import android.app.Application
import com.panjkhane.game.data.AppDb
import com.panjkhane.game.data.Repo
import com.panjkhane.game.data.SettingsStore
import com.panjkhane.game.engine.Lexicon

class PanjkhaneApp : Application() {
    lateinit var settings: SettingsStore
    lateinit var repo: Repo

    override fun onCreate() {
        super.onCreate()
        settings = SettingsStore(this)
        repo = Repo(AppDb.build(this), Lexicon(this), settings)
    }
}
