package com.panjkhane.game.game

import com.panjkhane.game.data.GameResult

class ModeStats(val played: Int, val wins: Int, val dist: IntArray, val current: Int, val best: Int, val bestGuess: Int?)

fun computeStats(list: List<GameResult>, daily: Boolean, today: Int): ModeStats {
    val sorted = if (daily) list.sortedBy { it.slot } else list
    val dist = IntArray(6)
    var run = 0; var best = 0; var wins = 0
    var lastWonDay = Int.MIN_VALUE
    var minG: Int? = null
    for (r in sorted) {
        if (r.won) {
            wins++
            dist[(r.guesses - 1).coerceIn(0, 5)]++
            minG = minG?.let { minOf(it, r.guesses) } ?: r.guesses
            run = if (daily) { if (lastWonDay == r.slot - 1) run + 1 else 1 } else run + 1
            lastWonDay = r.slot
            best = maxOf(best, run)
        } else run = 0
    }
    val current = if (daily && sorted.isNotEmpty() && today - sorted.last().slot > 1) 0 else run
    return ModeStats(sorted.size, wins, dist, current, best, minG)
}
