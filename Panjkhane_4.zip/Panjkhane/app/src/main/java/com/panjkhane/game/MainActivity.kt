package com.panjkhane.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.panjkhane.game.data.Settings
import com.panjkhane.game.ui.AppNav
import com.panjkhane.game.ui.PanjkhaneTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val app = application as PanjkhaneApp
        setContent {
            val st by app.settings.flow.collectAsState(initial = Settings())
            val dark = when (st.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            DisposableEffect(dark) {
                val style = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            PanjkhaneTheme(dark, st.colorBlind) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { AppNav(st) }
            }
        }
    }
}
