package com.panjkhane.game.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.panjkhane.game.PanjkhaneApp
import com.panjkhane.game.data.LevelResult
import com.panjkhane.game.data.Mode
import com.panjkhane.game.data.Repo
import com.panjkhane.game.data.Settings
import com.panjkhane.game.engine.Persian
import com.panjkhane.game.engine.TileState
import com.panjkhane.game.game.Badge
import com.panjkhane.game.game.computeBadges
import com.panjkhane.game.game.computeStats
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val CHAPTER = 50

@Composable
fun AppNav(settings: Settings) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(nav, settings) }
        composable("levels") { LevelsScreen(nav) }
        composable("stats") { StatsScreen(nav) }
        composable("settings") { SettingsScreen(nav, settings) }
        composable("game/{mode}/{slot}", arguments = listOf(navArgument("slot") { type = NavType.IntType })) { e ->
            GameScreen(Mode.of(e.arguments!!.getString("mode")!!), e.arguments!!.getInt("slot"), nav, settings)
        }
    }
}

private fun countdown(ms: Long): String {
    val s = ms / 1000
    return String.format(java.util.Locale.US, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60).faDigits()
}

@Composable
private fun MenuCard(icon: String, title: String, subtitle: String, onClick: () -> Unit, primary: Boolean = false, progress: Float? = null) {
    val bg = if (primary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (primary) Color.White else MaterialTheme.colorScheme.onBackground
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(icon, fontSize = 30.sp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, color = fg, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = fg.copy(alpha = 0.8f), fontSize = 13.sp)
            if (progress != null) {
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(5.dp).clip(RoundedCornerShape(3.dp)),
                    color = fg, trackColor = fg.copy(alpha = 0.25f)
                )
            }
        }
        Text("‹", color = fg.copy(alpha = 0.7f), fontSize = 26.sp)
    }
}

@Composable
private fun MiniStat(modifier: Modifier, icon: String, value: String, label: String) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$icon $value", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
    }
}

@Composable
fun HomeScreen(nav: NavController, st: Settings) {
    val app = LocalContext.current.applicationContext as PanjkhaneApp
    val repo = app.repo
    val scope = rememberCoroutineScope()
    val levels by repo.levelResults().collectAsState(initial = emptyList())
    val all by repo.allResults().collectAsState(initial = emptyList())
    var today by remember { mutableIntStateOf(0) }
    var pendingYesterday by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        if (!app.settings.current().seenHelp) help = true
        while (true) { now = System.currentTimeMillis(); delay(1000) }
    }
    LaunchedEffect(all.size) {
        today = repo.today()
        pendingYesterday = repo.session(Mode.DAILY, today - 1) != null && repo.dailyResult(today - 1) == null
    }
    val done = levels.map { it.level }.toSet()
    val next = (1..Persian.LEVELS).firstOrNull { it !in done } ?: Persian.LEVELS
    val stars = levels.sumOf { starsFor(it.guesses) }
    val dailyStats = computeStats(all.filter { it.mode == "daily" }, true, today)
    val dailyDone = all.any { it.mode == "daily" && it.slot == today }
    val msLeft = 86_400_000L - Math.floorMod(now + Repo.IRAN_OFFSET_MS, 86_400_000L)

    ScreenScaffold("", onBack = null, actions = {
        TextButton(onClick = { help = true }) { Text("❓", fontSize = 20.sp) }
        TextButton(onClick = { nav.navigate("stats") }) { Text("📊", fontSize = 20.sp) }
        TextButton(onClick = { nav.navigate("settings") }) { Text("⚙️", fontSize = 20.sp) }
    }) {
        Column(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f), Color.Transparent)))
                .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val word = "کلمات"
                val pattern = listOf(TileState.CORRECT, TileState.PRESENT, TileState.ABSENT, TileState.CORRECT, TileState.PRESENT)
                word.forEachIndexed { i, ch -> Tile(ch, null, pattern[i], i, true, 50.dp, st.animations) }
            }
            Text("پنج‌خانه", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
            Text("کلمه‌ی پنج‌حرفی را در شش تلاش پیدا کن", fontSize = 14.sp, textAlign = TextAlign.Center)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MiniStat(Modifier.weight(1f), "🏁", done.size.fa(), "مرحله")
                MiniStat(Modifier.weight(1f), "⭐", stars.fa(), "ستاره")
                MiniStat(Modifier.weight(1f), "🔥", dailyStats.current.fa(), "رکورد روزانه")
            }
            MenuCard(
                "▶️", if (done.isEmpty()) "شروع بازی" else "ادامه از مرحله‌ی ${next.fa()}",
                "${done.size.fa()} از ${Persian.LEVELS.fa()} مرحله انجام شده",
                { nav.navigate("game/level/$next") }, primary = true, progress = done.size / Persian.LEVELS.toFloat()
            )
            MenuCard("🗺️", "همه‌ی مرحله‌ها", "بخش‌بندی‌شده؛ ستاره‌هایت را ببین", { nav.navigate("levels") })
            MenuCard(
                "📅", "چالش روزانه",
                if (dailyDone) "چالش بعدی تا ${countdown(msLeft)} دیگر" else "هر روز یک کلمه‌ی تازه، برای همه یکسان",
                { if (today > 0) nav.navigate("game/daily/$today") }
            )
            if (pendingYesterday) MenuCard("⏳", "چالش دیروز نیمه‌کاره مانده", "تا نیمه‌شب امروز فرصت داری تمامش کنی", { nav.navigate("game/daily/${today - 1}") })
            MenuCard("♾️", "حالت بی‌پایان", "کلمه‌ی تازه، بدون ترتیب و بدون محدودیت", { nav.navigate("game/infinite/0") })
            Spacer(Modifier.height(16.dp))
        }
    }
    if (help) AlertDialog(
        onDismissRequest = { help = false; scope.launch { app.settings.setSeenHelp() } },
        confirmButton = { TextButton(onClick = { help = false; scope.launch { app.settings.setSeenHelp() } }) { Text("متوجه شدم") } },
        title = { Text("روش بازی") },
        text = {
            Text(
                "کلمه‌ی پنج‌حرفی پنهان را در شش تلاش حدس بزن. بعد از هر حدس، رنگ هر خانه نشان می‌دهد:\n\n" +
                    "🟩 سبز: حرف درست است و جایش هم درست است.\n" +
                    "🟨 زرد: حرف در کلمه هست، اما جایش اینجا نیست.\n" +
                    "⬛ خاکستری: این حرف در کلمه نیست.\n\n" +
                    "🔎 سرنخ: اگر گیر کردی، یک اشاره‌ی غیرمستقیم درباره‌ی کلمه می‌گیری.\n" +
                    "💡 راهنما: یک حرف از جای درستش را نشان می‌دهد؛ تعدادش محدود است.\n" +
                    "⭐ هر چه با حدس کمتر ببری، ستاره‌ی بیشتری می‌گیری.\n" +
                    "✍️ برای نوشتن «آ»، کلید «ا» را نگه دار (مثل Gboard).\n\n" +
                    "ترتیب مرحله‌ها برای هر بازیکن تصادفی و مخصوص خودش است."
            )
        }
    )
}

@Composable
private fun ChapterHeader(chapter: Int, map: Map<Int, LevelResult>) {
    val first = chapter * CHAPTER + 1
    val done = (first until first + CHAPTER).count { it in map }
    val stars = (first until first + CHAPTER).sumOf { map[it]?.let { r -> starsFor(r.guesses) } ?: 0 }
    Column(Modifier.fillMaxWidth().padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("بخش ${(chapter + 1).fa()}", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
            Text("${done.fa()} از ${CHAPTER.fa()}  •  ⭐ ${stars.fa()}", fontSize = 12.sp)
        }
        LinearProgressIndicator(
            progress = { done / CHAPTER.toFloat() }, modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)),
            color = LocalGameColors.current.correct, trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

@Composable
private fun LevelCell(level: Int, r: LevelResult?, isNext: Boolean, unlocked: Boolean, onClick: () -> Unit) {
    val colors = LocalGameColors.current
    val bg = when {
        r != null -> colors.correct
        unlocked -> MaterialTheme.colorScheme.surfaceVariant
        else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
    }
    val shape = RoundedCornerShape(12.dp)
    Box(
        Modifier.aspectRatio(1f).clip(shape).background(bg)
            .then(if (isNext) Modifier.border(2.5.dp, MaterialTheme.colorScheme.primary, shape) else Modifier)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(level.fa(), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = if (r != null) Color.White else MaterialTheme.colorScheme.onBackground)
            if (r != null) Text("★".repeat(starsFor(r.guesses)), fontSize = 10.sp, color = Color(0xFFFFD54F))
            else if (!unlocked) Text("🔒", fontSize = 10.sp)
        }
    }
}

@Composable
fun LevelsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as PanjkhaneApp
    val results by app.repo.levelResults().collectAsState(initial = null)
    val state = rememberLazyGridState()
    var scrolled by remember { mutableStateOf(false) }
    var review by remember { mutableStateOf<Int?>(null) }
    var reviewAnswer by remember { mutableStateOf<String?>(null) }
    val map = (results ?: emptyList()).associateBy { it.level }
    val next = (1..Persian.LEVELS).firstOrNull { it !in map } ?: Persian.LEVELS
    LaunchedEffect(results) {
        if (results != null && !scrolled) {
            scrolled = true
            val idx = (next - 1) + (next - 1) / CHAPTER + 1
            state.scrollToItem(maxOf(0, idx - 12))
        }
    }
    LaunchedEffect(review) { reviewAnswer = review?.let { app.repo.levelAnswer(it) } }

    ScreenScaffold("مرحله‌ها", onBack = { nav.popBackStack() }) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(5), state = state, contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (chapter in 0 until Persian.LEVELS / CHAPTER) {
                item(span = { GridItemSpan(maxLineSpan) }) { ChapterHeader(chapter, map) }
                items(CHAPTER) { i ->
                    val level = chapter * CHAPTER + i + 1
                    val r = map[level]
                    val unlocked = level == 1 || (level - 1) in map
                    LevelCell(level, r, level == next, unlocked) {
                        when {
                            r != null -> review = level
                            unlocked -> nav.navigate("game/level/$level")
                            else -> android.widget.Toast.makeText(ctx, "اول مرحله‌ی قبل را تمام کن", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }
    review?.let { level ->
        val r = map[level]
        val ans = reviewAnswer
        if (r != null && ans != null) AlertDialog(
            onDismissRequest = { review = null },
            title = { Text("مرحله‌ی ${level.fa()}  ${"⭐".repeat(starsFor(r.guesses))}") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Board(r.words.split(" ").filter { it.isNotEmpty() }, "", ans, emptyMap(), -1, 0, 38.dp, false)
                    Spacer(Modifier.height(8.dp))
                    Text("کلمه: $ans", fontWeight = FontWeight.Bold)
                    app.repo.lex.clueFor(ans)?.let { Text(it, fontSize = 13.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { review = null; nav.navigate("game/level/$level") }) { Text("بازی دوباره") } },
            dismissButton = { TextButton(onClick = { review = null }) { Text("بستن") } }
        )
    }
}

@Composable
fun StatsScreen(nav: NavController) {
    val app = LocalContext.current.applicationContext as PanjkhaneApp
    val all by app.repo.allResults().collectAsState(initial = emptyList())
    val levels by app.repo.levelResults().collectAsState(initial = emptyList())
    var today by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { today = app.repo.today() }
    val tabs = listOf("مرحله‌ها", "روزانه", "بی‌پایان", "نشان‌ها")
    val modeIds = listOf("level", "daily", "infinite")
    val badges = computeBadges(levels, all)
    ScreenScaffold("آمار", onBack = { nav.popBackStack() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                tabs.forEachIndexed { i, label -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) }) }
            }
            if (tab == 3) {
                Text("${badges.count { it.unlocked }.fa()} از ${badges.size.fa()} نشان به دست آمده", fontWeight = FontWeight.Bold)
                badges.forEach { BadgeRow(it) }
            } else {
                val st = computeStats(all.filter { it.mode == modeIds[tab] }, tab == 1, today)
                if (tab == 0) Text(
                    "مرحله‌های انجام‌شده: ${levels.size.fa()} از ${Persian.LEVELS.fa()}  •  ⭐ ${levels.sumOf { starsFor(it.guesses) }.fa()}",
                    fontWeight = FontWeight.Bold
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    StatBox("بازی", st.played.fa())
                    StatBox("درصد برد", (if (st.played == 0) 0 else st.wins * 100 / st.played).fa() + "٪")
                    StatBox("رکورد پیاپی", st.current.fa())
                    StatBox("بهترین رکورد", st.best.fa())
                }
                st.bestGuess?.let { Text("کم‌ترین تعداد حدس برای یک برد: ${it.fa()}") }
                Text("توزیع بردها", fontWeight = FontWeight.Bold)
                val max = (st.dist.maxOrNull() ?: 0).coerceAtLeast(1)
                st.dist.forEachIndexed { i, n ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text((i + 1).fa(), modifier = Modifier.width(18.dp))
                        Box(
                            Modifier.fillMaxWidth(maxOf(0.08f, n.toFloat() / max)).height(24.dp).clip(RoundedCornerShape(4.dp))
                                .background(if (n > 0) LocalGameColors.current.correct else LocalGameColors.current.absent),
                            contentAlignment = Alignment.CenterStart
                        ) { Text(n.fa(), color = Color.White, modifier = Modifier.padding(horizontal = 8.dp), fontSize = 13.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun BadgeRow(b: Badge) {
    val alpha = if (b.unlocked) 1f else 0.45f
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(b.icon, fontSize = 30.sp, modifier = Modifier.padding(end = 2.dp).alpha(alpha))
        Column(Modifier.weight(1f)) {
            Text(b.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground.copy(alpha = alpha))
            Text(b.desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = alpha * 0.8f))
        }
        Text(
            if (b.unlocked) "✓" else "${minOf(b.have, b.need).fa()} از ${b.need.fa()}",
            fontSize = 12.sp, fontWeight = FontWeight.Bold,
            color = if (b.unlocked) LocalGameColors.current.correct else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
        )
    }
}

@Composable
private fun StatBox(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 11.sp)
    }
}

@Composable
fun SettingsScreen(nav: NavController, st: Settings) {
    val app = LocalContext.current.applicationContext as PanjkhaneApp
    val scope = rememberCoroutineScope()
    var confirmReset by remember { mutableStateOf(false) }
    ScreenScaffold("تنظیمات", onBack = { nav.popBackStack() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("پوسته", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("خودکار", "روشن", "تیره").forEachIndexed { i, l ->
                    FilterChip(selected = st.theme == i, onClick = { scope.launch { app.settings.setTheme(i) } }, label = { Text(l) })
                }
            }
            SwitchRow("لرزش هنگام لمس کلید", st.haptics) { scope.launch { app.settings.setHaptics(it) } }
            SwitchRow("رنگ‌های مناسب کوررنگی (نارنجی و آبی)", st.colorBlind) { scope.launch { app.settings.setColorBlind(it) } }
            SwitchRow("نمایش دکمه‌ی راهنما (چراغ)", st.hints) { scope.launch { app.settings.setHints(it) } }
            SwitchRow("افکت صدا (بوق کوتاه برد و باخت)", st.sound) { scope.launch { app.settings.setSound(it) } }
            SwitchRow("انیمیشن چرخش خانه‌ها", st.animations) { scope.launch { app.settings.setAnimations(it) } }
            SwitchRow("حدس آزاد (هر ترکیب پنج‌حرفی پذیرفته شود)", st.freeGuess) { scope.launch { app.settings.setFreeGuess(it) } }
            Text(
                "وقتی «حدس آزاد» خاموش است (حالت پیش‌فرض)، فقط کلمه‌های فهرست بازی (بیش از ۱۰ هزار واژه) پذیرفته می‌شود. اگر واژه‌ی درستی را نپذیرفت، این گزینه را روشن کن.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("شروع دوباره (حذف پیشرفت)") }
            Text(
                "با شروع دوباره، همه‌ی مرحله‌ها و آمار پاک می‌شود و ترتیب تازه‌ای از مرحله‌ها برایت ساخته می‌شود.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }
    }
    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false },
        title = { Text("حذف همه‌ی پیشرفت؟") },
        text = { Text("این کار برگشت‌پذیر نیست.") },
        confirmButton = {
            TextButton(onClick = { confirmReset = false; scope.launch { app.repo.resetProgress(); nav.popBackStack() } }) { Text("حذف کن") }
        },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("انصراف") } }
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
