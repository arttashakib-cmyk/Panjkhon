package com.panjkhane.game.data

import androidx.room.withTransaction
import com.panjkhane.game.engine.LevelOrder
import com.panjkhane.game.engine.Lexicon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.time.LocalDate
import kotlin.random.Random

enum class Mode(val id: String) {
    LEVEL("level"), DAILY("daily"), INFINITE("infinite");
    companion object { fun of(id: String): Mode = entries.first { it.id == id } }
}

fun interface TimeSource { fun nowMillis(): Long }

class Repo(
    private val db: AppDb,
    val lex: Lexicon,
    private val settings: SettingsStore,
    private val time: TimeSource = TimeSource { System.currentTimeMillis() }
) {
    private val dao = db.dao()
    private var order: List<Int>? = null
    private val orderLock = Mutex()

    companion object {
        const val IRAN_OFFSET_MS = 12_600_000L // +03:30، بدون ساعت تابستانی
        const val HORIZON = 1095
        val DAILY_START: Int = LocalDate.of(2026, 11, 1).toEpochDay().toInt()
    }

    /** ترتیب تصادفیِ مخصوص همین بازیکن برای ۱۰۰۰ کلمه‌ی مرحله‌ها */
    suspend fun levelOrder(): List<Int> = orderLock.withLock {
        order ?: LevelOrder.build(lex.levelAnswers, lex::clueFor, lex::isHard, settings.levelSeed()).also { order = it }
    }

    suspend fun levelAnswer(level: Int): String = lex.levelAnswers[levelOrder()[level - 1]]

    /** حذف همه‌ی پیشرفت و ساخت ترتیب تازه */
    suspend fun resetProgress() {
        withContext(Dispatchers.IO) { db.clearAllTables() }
        orderLock.withLock { order = null; settings.newLevelSeed() }
    }

    fun levelResults(): Flow<List<LevelResult>> = dao.levelResults()
    fun allResults(): Flow<List<GameResult>> = dao.allResults()

    /** روز جاری به وقت ایران؛ هرگز عقب‌تر از آخرین روزی که برنامه دیده نمی‌رود (محافظ در برابر برگرداندن ساعت). */
    suspend fun today(): Int {
        val computed = Math.floorDiv(time.nowMillis() + IRAN_OFFSET_MS, 86_400_000L).toInt()
        val seen = settings.lastSeenDay()
        val t = maxOf(computed, seen, DAILY_START)
        if (t != seen) settings.setLastSeenDay(t)
        return t
    }

    suspend fun ensureSchedule() {
        val need = today() + HORIZON
        val last = dao.maxScheduled() ?: (DAILY_START - 1)
        if (last >= need) return
        val n = lex.pool.size
        val rows = ArrayList<DailySchedule>()
        var day = last + 1
        while (day <= need) {
            val perm = (0 until n).toList().shuffled(Random(day.toLong()))
            for (idx in perm) {
                if (day > need) break
                rows.add(DailySchedule(day, idx, 1)); day++
            }
        }
        dao.addSchedule(rows)
    }

    suspend fun dailyWordIndex(day: Int): Int {
        ensureSchedule()
        return (dao.schedule(day) ?: dao.schedule(DAILY_START))!!.wordIndex
    }

    suspend fun session(mode: Mode, slot: Int) = dao.session(mode.id, slot)
    suspend fun saveSession(s: GameSession) = dao.putSession(s)
    suspend fun deleteSession(mode: Mode, slot: Int) = dao.deleteSession(mode.id, slot)
    suspend fun dailyResult(day: Int) = dao.dailyResult(day)
    suspend fun levelResult(level: Int) = dao.levelResult(level)

    suspend fun newSession(mode: Mode, slot: Int, answer: String): GameSession =
        GameSession(mode.id, slot, answer, "", "").also { dao.putSession(it) }

    suspend fun newInfiniteSession(): GameSession = db.withTransaction {
        var st = dao.infinite() ?: InfiniteState(1, System.nanoTime(), 0, 0)
        if (st.position >= lex.pool.size) st = st.copy(seed = st.seed + 1, position = 0, hintsUsed = 0)
        val perm = lex.pool.indices.toList().shuffled(Random(st.seed))
        val word = lex.pool[perm[st.position]]
        dao.putInfinite(st.copy(position = st.position + 1))
        GameSession(Mode.INFINITE.id, 0, word, "", "").also { dao.putSession(it) }
    }

    suspend fun infiniteHintsUsed(): Int = dao.infinite()?.hintsUsed ?: 0
    suspend fun useInfiniteHint() {
        val st = dao.infinite() ?: return
        dao.putInfinite(st.copy(hintsUsed = st.hintsUsed + 1))
    }

    suspend fun finish(mode: Mode, slot: Int, won: Boolean, guesses: List<String>) {
        db.withTransaction {
            dao.deleteSession(mode.id, slot)
            if (mode == Mode.DAILY && dao.dailyResult(slot) != null) return@withTransaction
            val words = guesses.joinToString(" ")
            dao.addResult(GameResult(mode = mode.id, slot = slot, won = won, guesses = guesses.size, words = words, at = time.nowMillis()))
            if (mode == Mode.LEVEL && won) {
                val old = dao.levelResult(slot)
                if (old == null || guesses.size < old.guesses) dao.putLevelResult(LevelResult(slot, guesses.size, words))
            }
        }
    }
}
