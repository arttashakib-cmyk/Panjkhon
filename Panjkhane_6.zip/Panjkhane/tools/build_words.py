# -*- coding: utf-8 -*-
"""ساخت فایل‌های واژه‌ی بازی.

ورودی:
  tools/clues_*.txt        هر خط: کلمه=سرنخ
  tools/rare.txt           کلمه‌های کم‌کاربرد/نام خاص (در ۱۵۰ مرحله‌ی اول نمی‌آیند)
  tools/dictionary_5.txt   فرهنگ واژه‌های مجاز برای حدس
  tools/order_levels.txt   ترتیب قفل‌شده‌ی ۱۰۰۰ کلمه‌ی مرحله‌ها (هرگز تغییر نکند!)
  tools/order_extra.txt    ترتیب قفل‌شده‌ی کلمه‌های اضافی (فقط به انتها اضافه می‌شود)
خروجی: app/src/main/assets/{answers_levels,answers_extra,guesses}.txt

کلمه‌ی تازه که در clues_*.txt بیاید و در فرهنگ باشد، به انتهای order_extra اضافه می‌شود؛
پس ترتیب مرحله‌ها و برنامه‌ی چالش روزانه‌ی بازیکنان فعلی به‌هم نمی‌ریزد.
"""
import os, glob
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
ALPHA = set("آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی")
LEVELS = 1000

def words_of(name):
    return [w.strip() for w in open(os.path.join(HERE, name), encoding="utf-8") if w.strip()]

RARE = set(open(os.path.join(HERE, "rare.txt"), encoding="utf-8").read().split())
DICT = set(words_of("dictionary_5.txt"))
levels = words_of("order_levels.txt")
extra = words_of("order_extra.txt")
assert len(levels) == LEVELS, len(levels)

pairs = {}
for f in sorted(glob.glob(os.path.join(HERE, "clues_*.txt"))):
    for line in open(f, encoding="utf-8"):
        line = line.strip()
        if "=" not in line: continue
        w, c = line.split("=", 1)
        w, c = w.strip(), c.strip()
        if len(w) == 5 and all(ch in ALPHA for ch in w) and w not in pairs and w not in c and "|" not in c:
            pairs[w] = c

known = set(levels) | set(extra)
added = [w for w in pairs if w not in known and w in DICT]
skipped = [w for w in pairs if w not in known and w not in DICT]
extra += added
missing = [w for w in levels + extra if w not in pairs]
assert not missing, missing[:10]

EXTRA_GUESS = """
خوردن نوشتن شنیدن گرفتن ماندن رسیدن پریدن دویدن نشستن دوختن ساختن بافتن کاشتن شکستن خریدن آفریدن
آشفته آلوده آهنین آبکی آبیاری آتشی آزادانه آشنای آموخته نوشته پدیده پدیدار پیروان پیشوا پیشگو
عصبی عاطفی عاشقی دلبری دلاور خوانا خوانده کارتن کارمند کارآمد سکوی سکوت سکونت منشور منشی منتظر
اشتیاق اشتهار اشتغال بازرگان بازیکن چاقوی چاپگر مسجدی مسجد
""".split()
guess = {w for w in (DICT | set(EXTRA_GUESS)) if len(w) == 5 and all(c in ALPHA for c in w)} - set(levels) - set(extra)

def line(w):
    return f"{w}|{pairs[w]}" + ("|r" if w in RARE else "")
out = os.path.join(ROOT, "app/src/main/assets")
os.makedirs(out, exist_ok=True)
def put(name, lines):
    with open(os.path.join(out, name), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
put("answers_levels.txt", [line(w) for w in levels])
put("answers_extra.txt", [line(w) for w in extra])
put("guesses.txt", sorted(guess))
with open(os.path.join(HERE, "order_extra.txt"), "w", encoding="utf-8") as fh:
    fh.write("\n".join(extra) + "\n")
print(f"levels {len(levels)} | extra {len(extra)} (+{len(added)} new) | guess-only {len(guess)}")
if skipped: print("not in dictionary, skipped:", len(skipped), skipped[:25])
