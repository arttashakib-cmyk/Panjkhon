package com.panjkhane.game.data

import androidx.room.withTransaction
import com.panjkhane.game.engine.LevelOrder
import com.panjkhane.game.engine.Lexicon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.time.LocalDate
import kotlin.random.Random

enum class Mode(val id: String) {
    LEVEL("level"), DAILY("daily"), INFINITE("infinite");
    companion object { fun of(id: String): Mode = entries.first { it.id == id } }
}

fun interface TimeSource { fun nowMillis(): Long }

class Repo(
    private val db: AppDb,
    val lex: Lexicon,
    private val settings: SettingsStore,
    private val time: TimeSource = TimeSource { System.currentTimeMillis() }
) {
    private val dao = db.dao()
    private var order: List<Int>? = null
    private val orderLock = Mutex()

    companion object {
        const val IRAN_OFFSET_MS = 12_600_000L // +03:30، بدون ساعت تابستانی
        val DAILY_START: Int = LocalDate.of(2026, 11, 1).toEpochDay().toInt()
    }

    /** ترتیب تصادفیِ مخصوص همین بازیکن برای ۱۰۰۰ کلمه‌ی مرحله‌ها */
    suspend fun levelOrder(): List<Int> = orderLock.withLock {
        order ?: LevelOrder.build(lex.levelAnswers, lex::orderClue, lex::isHard, settings.levelSeed()).also { order = it }
    }

    suspend fun levelAnswer(level: Int): String = lex.levelAnswers[levelOrder()[level - 1]]

    /** حذف همه‌ی پیشرفت و ساخت ترتیب تازه */
    suspend fun resetProgress() {
        withContext(Dispatchers.IO) { db.clearAllTables() }
        orderLock.withLock { order = null; settings.newLevelSeed() }
    }

    fun levelResults(): Flow<List<LevelResult>> = dao.levelResults()
    fun allResults(): Flow<List<GameResult>> = dao.allResults()

    /** روز جاری به وقت ایران؛ هرگز عقب‌تر از آخرین روزی که برنامه دیده نمی‌رود (محافظ در برابر برگرداندن ساعت). */
    suspend fun today(): Int {
        val computed = Math.floorDiv(time.nowMillis() + IRAN_OFFSET_MS, 86_400_000L).toInt()
        val seen = settings.lastSeenDay()
        val t = maxOf(computed, seen, DAILY_START)
        if (t != seen) settings.setLastSeenDay(t)
        return t
    }

    private class Tier(val start: Int, val n: Int)

    /**
     * جدول کلمه‌ی چالش روزانه؛ تابعی خالص از «روز» است تا روی همه‌ی گوشی‌ها یکسان باشد.
     * هر لایه از یک روز شروع می‌شود و با تعداد ثابتی از کلمه‌های فهرست کار می‌کند (هرگز این اعداد را عوض نکن؛
     * برای افزودن کلمه، یک لایه‌ی تازه با روز شروع آینده اضافه کن).
     */
    private val tiers = listOf(
        Tier(DAILY_START, 1109),
        Tier(LocalDate.of(2027, 3, 1).toEpochDay().toInt(), 1295)
    )
    private val permCache = HashMap<Long, IntArray>()

    fun dailyWordIndexFor(day: Int): Int {
        val d = maxOf(day, DAILY_START)
        val tier = tiers.last { it.start <= d }
        val offset = d - tier.start
        val chunk = offset / tier.n
        val pos = offset % tier.n
        val key = tier.start.toLong() * 100_000L + chunk
        val perm = synchronized(permCache) {
            permCache.getOrPut(key) {
                (0 until tier.n).toList().shuffled(Random((tier.start + chunk * tier.n).toLong())).toIntArray()
            }
        }
        return perm[pos]
    }

    suspend fun dailyWordIndex(day: Int): Int = dailyWordIndexFor(day).coerceAtMost(lex.pool.size - 1)

    suspend fun session(mode: Mode, slot: Int) = dao.session(mode.id, slot)
    suspend fun saveSession(s: GameSession) = dao.putSession(s)
    suspend fun deleteSession(mode: Mode, slot: Int) = dao.deleteSession(mode.id, slot)
    suspend fun dailyResult(day: Int) = dao.dailyResult(day)
    suspend fun levelResult(level: Int) = dao.levelResult(level)

    suspend fun newSession(mode: Mode, slot: Int, answer: String): GameSession =
        GameSession(mode.id, slot, answer, "", "").also { dao.putSession(it) }

    suspend fun newInfiniteSession(): GameSession = db.withTransaction {
        var st = dao.infinite() ?: InfiniteState(1, System.nanoTime(), 0, 0)
        if (st.position >= lex.pool.size) st = st.copy(seed = st.seed + 1, position = 0, hintsUsed = 0)
        val perm = lex.pool.indices.toList().shuffled(Random(st.seed))
        val word = lex.pool[perm[st.position]]
        dao.putInfinite(st.copy(position = st.position + 1))
        GameSession(Mode.INFINITE.id, 0, word, "", "").also { dao.putSession(it) }
    }

    suspend fun infiniteHintsUsed(): Int = dao.infinite()?.hintsUsed ?: 0
    suspend fun useInfiniteHint() {
        val st = dao.infinite() ?: return
        dao.putInfinite(st.copy(hintsUsed = st.hintsUsed + 1))
    }

    class FinishInfo(val stars: Int, val retry: Boolean)

    private fun starsOf(g: Int) = if (g <= 2) 3 else if (g <= 4) 2 else 1

    /**
     * پایان بازی. ستاره فقط برای «اولین تلاش» یک مرحله حساب می‌شود؛ بعد از باخت یا تکرار (که جواب را می‌دانی)
     * حداکثر یک ستاره می‌گیری و تکرارِ مرحله‌ی تمام‌شده چیزی را عوض نمی‌کند.
     */
    suspend fun finish(mode: Mode, slot: Int, won: Boolean, guesses: List<String>): FinishInfo? {
        return db.withTransaction<FinishInfo?> {
            dao.deleteSession(mode.id, slot)
            if (mode == Mode.DAILY && dao.dailyResult(slot) != null) return@withTransaction null
            val prior = if (mode == Mode.LEVEL) dao.attempts(mode.id, slot) else 0
            val words = guesses.joinToString(" ")
            dao.addResult(GameResult(mode = mode.id, slot = slot, won = won, guesses = guesses.size, words = words, at = time.nowMillis()))
            if (mode != Mode.LEVEL || !won) return@withTransaction null
            val old = dao.levelResult(slot)
            when {
                old != null -> FinishInfo(starsOf(old.guesses), true)
                prior == 0 -> {
                    dao.putLevelResult(LevelResult(slot, guesses.size, words))
                    FinishInfo(starsOf(guesses.size), false)
                }
                else -> {
                    dao.putLevelResult(LevelResult(slot, maxOf(guesses.size, 5), words))
                    FinishInfo(1, true)
                }
            }
        }
    }
}
