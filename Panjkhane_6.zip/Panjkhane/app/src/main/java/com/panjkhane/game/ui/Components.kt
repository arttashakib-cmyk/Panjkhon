package com.panjkhane.game.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panjkhane.game.engine.Persian
import com.panjkhane.game.engine.TileState
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.delay

@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) TextButton(onClick = onBack) { Text("→", fontSize = 24.sp) }
                Text(
                    title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                actions()
            }
            content()
        }
    }
}

@Composable
fun Tile(ch: Char?, ghost: Char?, state: TileState?, index: Int, animate: Boolean, size: Dp, animations: Boolean, celebrate: Boolean = false) {
    val colors = LocalGameColors.current
    val rot = remember { Animatable(if (state != null && !animate) 180f else 0f) }
    val pop = remember { Animatable(1f) }
    val hop = remember { Animatable(0f) }
    LaunchedEffect(celebrate) {
        if (celebrate && animations) { delay(index * 100L); hop.animateTo(-16f, tween(140)); hop.animateTo(0f, tween(200)) }
    }
    LaunchedEffect(ch) {
        if (ch != null && state == null) { pop.snapTo(1.14f); pop.animateTo(1f, tween(110)) } else pop.snapTo(1f)
    }
    LaunchedEffect(state) {
        if (state == null) rot.snapTo(0f)
        else if (rot.value < 180f) {
            if (animate && animations) { delay(index * 260L); rot.animateTo(180f, tween(420)) } else rot.snapTo(180f)
        }
    }
    val back = rot.value > 90f
    val bg = if (back) colors.of(state) else Color.Transparent
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier.size(size)
            .graphicsLayer { rotationX = rot.value; cameraDistance = 12f * density; scaleX = pop.value; scaleY = pop.value; translationY = hop.value * density }
            .background(bg, shape)
            .border(2.dp, if (back) bg else if (ch != null) colors.borderFilled else colors.border, shape),
        contentAlignment = Alignment.Center
    ) {
        val t = ch ?: ghost
        if (t != null) {
            Text(
                t.toString(), fontSize = (size.value * 0.5f).sp, fontWeight = FontWeight.Bold,
                color = if (back) Color.White else if (ch == null) colors.ghost else MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.graphicsLayer { rotationX = if (back) 180f else 0f }
            )
        }
    }
}

@Composable
fun Board(
    guesses: List<String>, current: String, answer: String, hints: Map<Int, Char>,
    animateRow: Int, shake: Int, tile: Dp, animations: Boolean, celebrateRow: Int = -1
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        for (r in 0 until Persian.MAX_GUESSES) {
            val rowGuess = guesses.getOrNull(r)
            val states = rowGuess?.let { Persian.evaluate(it, answer) }
            val isCurrent = r == guesses.size
            val off = remember { Animatable(0f) }
            LaunchedEffect(shake) {
                if (shake > 0 && isCurrent) {
                    repeat(3) { off.animateTo(10f, tween(45)); off.animateTo(-10f, tween(45)) }
                    off.animateTo(0f, tween(45))
                }
            }
            Row(Modifier.offset(x = if (isCurrent) off.value.dp else 0.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (c in 0 until Persian.WORD_LENGTH) {
                    Tile(
                        ch = rowGuess?.getOrNull(c) ?: if (isCurrent) current.getOrNull(c) else null,
                        ghost = if (isCurrent) hints[c] else null,
                        state = states?.getOrNull(c), index = c, animate = r == animateRow, size = tile, animations = animations, celebrate = r == celebrateRow
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun KeyBox(
    modifier: Modifier, label: String, bg: Color, fg: Color, onClick: () -> Unit, fontSize: Int = 22,
    shape: Shape = RoundedCornerShape(12.dp), onLongClick: (() -> Unit)? = null, hint: String? = null, hintBg: Color? = null, height: Dp = 46.dp
) {
    Box(
        modifier.height(height).clip(shape).background(bg).combinedClickable(onClick = onClick, onLongClick = onLongClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = fg, fontSize = fontSize.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center)
        if (hint != null) {
            Text(
                hint, fontSize = 10.sp, color = if (hintBg != null) Color.White else fg.copy(alpha = 0.6f),
                modifier = Modifier.align(Alignment.TopEnd).padding(top = 2.dp, end = 3.dp)
                    .then(if (hintBg != null) Modifier.background(hintBg, CircleShape).padding(horizontal = 3.dp) else Modifier)
            )
        }
    }
}

/** کیبورد هم‌ترتیب و هم‌اندازه با Gboard فارسی: ردیف‌های ۱۱تایی، حذف در انتهای ردیف سوم، ثبت در ردیف آخر */
@Composable
fun Keyboard(states: Map<Char, TileState>, onKey: (Char) -> Unit, onDelete: () -> Unit, onEnter: () -> Unit, big: Boolean = false) {
    val keyH = if (big) 58.dp else 46.dp
    val fs = if (big) 26 else 22
    val colors = LocalGameColors.current
    val onBg = MaterialTheme.colorScheme.onBackground
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Persian.KEY_ROWS.forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (r == 2) KeyBox(Modifier.weight(1f), "⌫", colors.keyAccent, onBg, onDelete, fontSize = fs, height = keyH)
                for (c in row) {
                    val s = states[c]
                    val bg = if (s == null) colors.key else colors.of(s)
                    val fg = if (s == null) onBg else Color.White
                    if (c == 'ا') {
                        val hintState = states['آ']
                        KeyBox(
                            Modifier.weight(1f), "ا", bg, fg, { onKey('ا') },
                            hint = "آ", hintBg = hintState?.let { colors.of(it) }, onLongClick = { onKey('آ') }, fontSize = fs, height = keyH
                        )
                    } else {
                        KeyBox(Modifier.weight(1f), c.toString(), bg, fg, { onKey(c) }, fontSize = fs, height = keyH)
                    }
                }
            }
        }
        KeyBox(Modifier.fillMaxWidth(), "ثبت  ↵", colors.correct, Color.White, onEnter, 18, RoundedCornerShape(24.dp), height = keyH)
    }
}

private class Particle(val x: Float, val speed: Float, val size: Float, val color: Color, val phase: Float, val sway: Float, val spin: Float)

/** بارش کاغذرنگی هنگام برد */
@Composable
fun Confetti(modifier: Modifier = Modifier) {
    val particles = remember {
        val palette = listOf(Color(0xFF3F9142), Color(0xFFB59F3B), Color(0xFFE57373), Color(0xFF64B5F6), Color(0xFFBA68C8), Color(0xFFFFD54F))
        List(70) {
            Particle(
                x = Random.nextFloat(), speed = 0.6f + Random.nextFloat() * 0.8f, size = 8f + Random.nextFloat() * 10f,
                color = palette.random(), phase = Random.nextFloat() * 6.28f, sway = 10f + Random.nextFloat() * 30f, spin = Random.nextFloat() * 360f
            )
        }
    }
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) { progress.animateTo(1f, tween(2600, easing = LinearEasing)) }
    if (progress.value < 1f) {
        Canvas(modifier.fillMaxSize()) {
            val p = progress.value
            for (pt in particles) {
                val y = -20f + (size.height + 60f) * p * pt.speed
                val x = pt.x * size.width + sin(p * 9f + pt.phase) * pt.sway
                rotate(degrees = pt.spin + p * 360f, pivot = Offset(x, y)) {
                    drawRect(color = pt.color, topLeft = Offset(x - pt.size / 2, y - pt.size / 2), size = Size(pt.size, pt.size * 0.6f))
                }
            }
        }
    }
}
