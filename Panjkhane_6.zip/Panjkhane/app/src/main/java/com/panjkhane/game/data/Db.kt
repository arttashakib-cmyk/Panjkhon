package com.panjkhane.game.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "level_result")
data class LevelResult(@PrimaryKey val level: Int, val guesses: Int, val words: String)

@Entity(tableName = "game_session", primaryKeys = ["mode", "slot"])
data class GameSession(val mode: String, val slot: Int, val answer: String, val guesses: String, val hints: String)

@Entity(tableName = "game_result", indices = [Index("mode")])
data class GameResult(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mode: String, val slot: Int, val won: Boolean, val guesses: Int, val words: String, val at: Long
)

@Entity(tableName = "daily_schedule")
data class DailySchedule(@PrimaryKey val epochDay: Int, val wordIndex: Int, val version: Int)

@Entity(tableName = "infinite_state")
data class InfiniteState(@PrimaryKey val id: Int = 1, val seed: Long, val position: Int, val hintsUsed: Int)

@Dao
interface GameDao {
    @Query("SELECT * FROM level_result ORDER BY level") fun levelResults(): Flow<List<LevelResult>>
    @Query("SELECT * FROM level_result WHERE level = :l") suspend fun levelResult(l: Int): LevelResult?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putLevelResult(r: LevelResult)

    @Query("SELECT * FROM game_session WHERE mode = :m AND slot = :s") suspend fun session(m: String, s: Int): GameSession?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSession(s: GameSession)
    @Query("DELETE FROM game_session WHERE mode = :m AND slot = :s") suspend fun deleteSession(m: String, s: Int)

    @Insert suspend fun addResult(r: GameResult)
    @Query("SELECT * FROM game_result ORDER BY id") fun allResults(): Flow<List<GameResult>>
    @Query("SELECT COUNT(*) FROM game_result WHERE mode = :m AND slot = :s") suspend fun attempts(m: String, s: Int): Int
    @Query("SELECT * FROM game_result WHERE mode = 'daily' AND slot = :s LIMIT 1") suspend fun dailyResult(s: Int): GameResult?

    @Query("SELECT * FROM daily_schedule WHERE epochDay = :d") suspend fun schedule(d: Int): DailySchedule?
    @Query("SELECT MAX(epochDay) FROM daily_schedule") suspend fun maxScheduled(): Int?
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun addSchedule(list: List<DailySchedule>)

    @Query("SELECT * FROM infinite_state WHERE id = 1") suspend fun infinite(): InfiniteState?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putInfinite(s: InfiniteState)
}

@Database(
    entities = [LevelResult::class, GameSession::class, GameResult::class, DailySchedule::class, InfiniteState::class],
    version = 1, exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): GameDao

    companion object {
        fun build(ctx: Context): AppDb = Room.databaseBuilder(ctx, AppDb::class.java, "panjkhane.db").build()
    }
}
