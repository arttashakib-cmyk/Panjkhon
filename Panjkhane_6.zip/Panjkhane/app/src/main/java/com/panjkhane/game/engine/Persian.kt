package com.panjkhane.game.engine

import android.content.Context

enum class TileState { CORRECT, PRESENT, ABSENT }

object Persian {
    const val WORD_LENGTH = 5
    const val MAX_GUESSES = 6
    const val LEVELS = 1000

    /** ۳۳ حرف الفبای فارسی (آ جدا از ا) */
    val ALPHABET: List<Char> = "آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی".toList()
    val ALPHABET_SET: Set<Char> = ALPHABET.toSet()

    /**
     * چینش کیبورد Gboard فارسی؛ هر ردیف از راست به چپ نوشته شده (اولی راست‌ترین کلید است).
     * ردیف سوم در سمت راستش یک کلید حذف دارد. «آ» مثل خود Gboard با نگه‌داشتن کلید «ا» تایپ می‌شود.
     */
    val KEY_ROWS: List<List<Char>> = listOf(
        "جحخهعغفقثصض".toList(),
        "گکمنتالبیسش".toList(),
        "چوپدذرزژطظ".toList()
    )

    fun normalize(input: String): String {
        val sb = StringBuilder()
        for (c in input) {
            when {
                c.isWhitespace() -> {}
                c == '\u200c' || c == '\u200d' || c == '\u200e' || c == '\u200f' || c == '\u0640' || c == '\u00AD' || c == '\uFEFF' -> {}
                c in '\u064B'..'\u065F' || c == '\u0670' -> {}
                c == '\u064A' || c == '\u0649' || c == '\u0626' -> sb.append('ی')
                c == '\u0643' -> sb.append('ک')
                c == '\u0629' || c == '\u06C0' -> sb.append('ه')
                c == '\u0623' || c == '\u0625' || c == '\u0671' -> sb.append('ا')
                c == '\u0624' -> sb.append('و')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun isWord(w: String) = w.length == WORD_LENGTH && w.all { it in ALPHABET_SET }

    /** «آ» و «ا» هم‌ارز حساب می‌شوند؛ اگر بازیکن «ا» بزند و کلمه «آ» داشته باشد، درست است. */
    fun fold(c: Char): Char = if (c == 'آ') 'ا' else c
    fun fold(w: String): String = w.map { fold(it) }.joinToString("")
    fun sameWord(a: String, b: String): Boolean = fold(a) == fold(b)

    fun evaluate(guess: String, answer: String): List<TileState> {
        val g = fold(guess)
        val a = fold(answer)
        val res = Array(g.length) { TileState.ABSENT }
        val remaining = HashMap<Char, Int>()
        for (i in a.indices) {
            if (i < g.length && g[i] == a[i]) res[i] = TileState.CORRECT
            else remaining[a[i]] = (remaining[a[i]] ?: 0) + 1
        }
        for (i in g.indices) {
            if (res[i] != TileState.CORRECT) {
                val n = remaining[g[i]] ?: 0
                if (n > 0) { res[i] = TileState.PRESENT; remaining[g[i]] = n - 1 }
            }
        }
        return res.toList()
    }
}

class Lexicon(context: Context) {
    private val clues = HashMap<String, String>()
    private val rare = HashSet<String>()
    private val orderClues: Map<String, String> = readClueMap(context, "order_tokens.txt")
    val levelAnswers: List<String> = read(context, "answers_levels.txt")
    /** مجموعه‌ی پاسخ‌های ممکن برای روزانه و بی‌پایان؛ ترتیبش هرگز نباید عوض شود (فقط به انتها اضافه شود). */
    val pool: List<String> = levelAnswers + read(context, "answers_extra.txt")
    private val valid: Set<String> = (pool + readPlain(context, "guesses.txt")).map { Persian.fold(it) }.toHashSet()

    init { check(levelAnswers.size == Persian.LEVELS) { "answers_levels must have ${Persian.LEVELS} words" } }

    fun isValid(word: String, free: Boolean): Boolean =
        Persian.isWord(word) && (free || Persian.fold(word) in valid)

    /** کلمه‌ی کم‌کاربرد یا نام خاص (یا با حرف‌های سخت)؛ در مرحله‌های اول نمی‌آید */
    fun isHard(word: String): Boolean = word in rare || word.any { it in "ظضثذژ" }

    /** سرنخِ قفل‌شده فقط برای ساختن ترتیب مرحله‌ها (تغییر سرنخ‌ها نباید ترتیب بازیکن‌ها را به‌هم بزند) */
    fun orderClue(word: String): String? = orderClues[word]

    /** سرنخ غیرمستقیم برای کلمه (اگر داشته باشد) */
    fun clueFor(word: String): String? = clues[word]

    /** هر خط: کلمه|سرنخ */
    private fun read(context: Context, name: String): List<String> {
        val out = ArrayList<String>()
        context.assets.open(name).bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                val parts = line.split("|", limit = 3)
                val w = Persian.normalize(parts[0])
                if (!Persian.isWord(w)) continue
                out.add(w)
                if (parts.size > 1 && parts[1].isNotBlank()) clues[w] = parts[1].trim()
                if (parts.size > 2 && parts[2].trim() == "r") rare.add(w)
            }
        }
        return out
    }

    private fun readClueMap(context: Context, name: String): Map<String, String> {
        val m = HashMap<String, String>()
        context.assets.open(name).bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                val p = line.split("|", limit = 2)
                if (p.size == 2) m[Persian.normalize(p[0])] = p[1].trim()
            }
        }
        return m
    }

    private fun readPlain(context: Context, name: String): List<String> =
        context.assets.open(name).bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.map { Persian.normalize(it) }.filter { Persian.isWord(it) }.toList()
        }
}
