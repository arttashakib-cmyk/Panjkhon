package com.panjkhane.game.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

data class Settings(
    val theme: Int = 0, // 0 سیستم، 1 روشن، 2 تیره
    val haptics: Boolean = true,
    val colorBlind: Boolean = false,
    val hints: Boolean = true,
    val animations: Boolean = true,
    val freeGuess: Boolean = true,
    val seenHelp: Boolean = true
)

private val Context.dataStore by preferencesDataStore(name = "settings")

class SettingsStore(private val ctx: Context) {
    private object K {
        val THEME = intPreferencesKey("theme")
        val HAPTICS = booleanPreferencesKey("haptics")
        val CB = booleanPreferencesKey("colorblind")
        val HINTS = booleanPreferencesKey("hints")
        val ANIM = booleanPreferencesKey("animations")
        val FREE = booleanPreferencesKey("free_guess")
        val LAST_DAY = intPreferencesKey("last_seen_day")
        val SEEN = booleanPreferencesKey("seen_help")
        val SEED = longPreferencesKey("level_seed")
    }

    val flow: Flow<Settings> = ctx.dataStore.data.map { p ->
        Settings(
            theme = p[K.THEME] ?: 0, haptics = p[K.HAPTICS] ?: true, colorBlind = p[K.CB] ?: false,
            hints = p[K.HINTS] ?: true, animations = p[K.ANIM] ?: true, freeGuess = p[K.FREE] ?: true,
            seenHelp = p[K.SEEN] ?: false
        )
    }

    suspend fun setTheme(v: Int) { ctx.dataStore.edit { it[K.THEME] = v } }
    suspend fun setHaptics(v: Boolean) { ctx.dataStore.edit { it[K.HAPTICS] = v } }
    suspend fun setColorBlind(v: Boolean) { ctx.dataStore.edit { it[K.CB] = v } }
    suspend fun setHints(v: Boolean) { ctx.dataStore.edit { it[K.HINTS] = v } }
    suspend fun setAnimations(v: Boolean) { ctx.dataStore.edit { it[K.ANIM] = v } }
    suspend fun setFreeGuess(v: Boolean) { ctx.dataStore.edit { it[K.FREE] = v } }

    suspend fun setSeenHelp() { ctx.dataStore.edit { it[K.SEEN] = true } }

    /** بذر ترتیب مرحله‌ها؛ برای هر نصب/بازیکن یک‌بار ساخته می‌شود */
    suspend fun levelSeed(): Long {
        ctx.dataStore.data.first()[K.SEED]?.let { return it }
        val n = kotlin.random.Random.nextLong()
        ctx.dataStore.edit { it[K.SEED] = n }
        return n
    }
    suspend fun newLevelSeed() { ctx.dataStore.edit { it[K.SEED] = kotlin.random.Random.nextLong() } }

    suspend fun lastSeenDay(): Int = ctx.dataStore.data.first()[K.LAST_DAY] ?: 0
    suspend fun setLastSeenDay(d: Int) { ctx.dataStore.edit { it[K.LAST_DAY] = d } }
    suspend fun current(): Settings = flow.first()
}
