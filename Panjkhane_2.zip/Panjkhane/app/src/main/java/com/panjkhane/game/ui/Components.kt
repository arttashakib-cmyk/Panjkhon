package com.panjkhane.game.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.panjkhane.game.engine.Persian
import com.panjkhane.game.engine.TileState
import kotlinx.coroutines.delay

@Composable
fun ScreenScaffold(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) TextButton(onClick = onBack) { Text("→", fontSize = 24.sp) }
                Text(
                    title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                actions()
            }
            content()
        }
    }
}

@Composable
fun Tile(ch: Char?, ghost: Char?, state: TileState?, index: Int, animate: Boolean, size: Dp, animations: Boolean) {
    val colors = LocalGameColors.current
    val rot = remember { Animatable(if (state != null && !animate) 180f else 0f) }
    val pop = remember { Animatable(1f) }
    LaunchedEffect(ch) {
        if (ch != null && state == null) { pop.snapTo(1.14f); pop.animateTo(1f, tween(110)) } else pop.snapTo(1f)
    }
    LaunchedEffect(state) {
        if (state == null) rot.snapTo(0f)
        else if (rot.value < 180f) {
            if (animate && animations) { delay(index * 260L); rot.animateTo(180f, tween(420)) } else rot.snapTo(180f)
        }
    }
    val back = rot.value > 90f
    val bg = if (back) colors.of(state) else Color.Transparent
    val shape = RoundedCornerShape(6.dp)
    Box(
        Modifier.size(size)
            .graphicsLayer { rotationX = rot.value; cameraDistance = 12f * density; scaleX = pop.value; scaleY = pop.value }
            .background(bg, shape)
            .border(2.dp, if (back) bg else if (ch != null) colors.borderFilled else colors.border, shape),
        contentAlignment = Alignment.Center
    ) {
        val t = ch ?: ghost
        if (t != null) {
            Text(
                t.toString(), fontSize = (size.value * 0.5f).sp, fontWeight = FontWeight.Bold,
                color = if (back) Color.White else if (ch == null) colors.ghost else MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.graphicsLayer { rotationX = if (back) 180f else 0f }
            )
        }
    }
}

@Composable
fun Board(
    guesses: List<String>, current: String, answer: String, hints: Map<Int, Char>,
    animateRow: Int, shake: Int, tile: Dp, animations: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        for (r in 0 until Persian.MAX_GUESSES) {
            val rowGuess = guesses.getOrNull(r)
            val states = rowGuess?.let { Persian.evaluate(it, answer) }
            val isCurrent = r == guesses.size
            val off = remember { Animatable(0f) }
            LaunchedEffect(shake) {
                if (shake > 0 && isCurrent) {
                    repeat(3) { off.animateTo(10f, tween(45)); off.animateTo(-10f, tween(45)) }
                    off.animateTo(0f, tween(45))
                }
            }
            Row(Modifier.offset(x = if (isCurrent) off.value.dp else 0.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (c in 0 until Persian.WORD_LENGTH) {
                    Tile(
                        ch = rowGuess?.getOrNull(c) ?: if (isCurrent) current.getOrNull(c) else null,
                        ghost = if (isCurrent) hints[c] else null,
                        state = states?.getOrNull(c), index = c, animate = r == animateRow, size = tile, animations = animations
                    )
                }
            }
        }
    }
}

@Composable
private fun KeyBox(modifier: Modifier, label: String, bg: Color, fg: Color, onClick: () -> Unit, fontSize: Int = 18) {
    Box(
        modifier.height(46.dp).clip(RoundedCornerShape(6.dp)).background(bg).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = fg, fontSize = fontSize.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center) }
}

@Composable
fun Keyboard(states: Map<Char, TileState>, onKey: (Char) -> Unit, onDelete: () -> Unit, onEnter: () -> Unit) {
    val colors = LocalGameColors.current
    val onBg = MaterialTheme.colorScheme.onBackground
    Column(Modifier.fillMaxWidth().padding(horizontal = 3.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (row in Persian.KEY_ROWS) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                val pad = 12 - row.size
                if (pad > 0) Spacer(Modifier.weight(pad / 2f))
                for (c in row) {
                    val s = states[c]
                    KeyBox(Modifier.weight(1f), c.toString(), if (s == null) colors.key else colors.of(s), if (s == null) onBg else Color.White, { onKey(c) }, 17)
                }
                if (pad > 0) Spacer(Modifier.weight(pad / 2f))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            KeyBox(Modifier.weight(1f), "⌫", colors.key, onBg, onDelete, 20)
            KeyBox(Modifier.weight(2f), "ثبت", colors.correct, Color.White, onEnter, 16)
        }
    }
}
