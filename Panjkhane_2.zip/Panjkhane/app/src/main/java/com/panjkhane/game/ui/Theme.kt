package com.panjkhane.game.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.panjkhane.game.engine.TileState

data class GameColors(
    val correct: Color, val present: Color, val absent: Color,
    val key: Color, val border: Color, val borderFilled: Color, val ghost: Color
) {
    fun of(s: TileState?): Color = when (s) {
        TileState.CORRECT -> correct
        TileState.PRESENT -> present
        TileState.ABSENT -> absent
        null -> Color.Transparent
    }
}

fun gameColors(dark: Boolean, colorBlind: Boolean) = GameColors(
    correct = if (colorBlind) Color(0xFFF5793A) else Color(0xFF3F9142),
    present = if (colorBlind) Color(0xFF3D8FD6) else Color(0xFFB59F3B),
    absent = if (dark) Color(0xFF3A3A3C) else Color(0xFF787C7E),
    key = if (dark) Color(0xFF818384) else Color(0xFFD3D6DA),
    border = if (dark) Color(0xFF3A3A3C) else Color(0xFFD3D6DA),
    borderFilled = if (dark) Color(0xFF818384) else Color(0xFF878A8C),
    ghost = if (dark) Color(0x66FFFFFF) else Color(0x55000000)
)

val LocalGameColors = staticCompositionLocalOf { gameColors(false, false) }

@Composable
fun PanjkhaneTheme(dark: Boolean, colorBlind: Boolean, content: @Composable () -> Unit) {
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF66BB6A), background = Color(0xFF121213), surface = Color(0xFF121213),
        surfaceVariant = Color(0xFF2A2A2C), onBackground = Color(0xFFF2F2F2), onSurface = Color(0xFFF2F2F2)
    ) else lightColorScheme(
        primary = Color(0xFF2E7D32), background = Color.White, surface = Color.White,
        surfaceVariant = Color(0xFFF0F0F0), onBackground = Color(0xFF1A1A1B), onSurface = Color(0xFF1A1A1B)
    )
    androidx.compose.runtime.CompositionLocalProvider(LocalGameColors provides gameColors(dark, colorBlind)) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
