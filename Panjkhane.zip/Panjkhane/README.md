# پنج‌خانه

بازی کلمه‌ی پنج‌حرفی فارسی (الهام‌گرفته از Wordle) — اندروید نیتیو (Kotlin + Jetpack Compose + Room + DataStore).
۵۰۰ مرحله + چالش روزانه + حالت بی‌پایان. کاملاً آفلاین.

## ساخت APK با GitHub Actions
1. این پوشه را در یک مخزن GitHub بریز (شاخه‌ی main).
2. تب Actions → «Build APK» اجرا می‌شود (یا دستی Run workflow).
3. بعد از پایان، فایل APK را از بخش Artifacts دانلود کن.

## فهرست واژه‌ها
فایل‌های `app/src/main/assets/*.txt` با `tools/build_words.py` ساخته می‌شوند.
برای افزودن واژه، آن را به `tools/build_words.py` یا `tools/more_words.py` اضافه کن و اسکریپت را دوباره اجرا کن؛
ترتیب `answers_extra.txt` را بعد از انتشار تغییر نده (چالش روزانه به آن وابسته است).
