package com.panjkhane.game.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.compose.rememberNavController
import com.panjkhane.game.PanjkhaneApp
import com.panjkhane.game.data.Mode
import com.panjkhane.game.data.Settings
import com.panjkhane.game.engine.Persian
import com.panjkhane.game.game.computeStats
import kotlinx.coroutines.launch

@Composable
fun AppNav(settings: Settings) {
    val nav = rememberNavController()
    NavHost(nav, startDestination = "home") {
        composable("home") { HomeScreen(nav) }
        composable("levels") { LevelsScreen(nav) }
        composable("stats") { StatsScreen(nav) }
        composable("settings") { SettingsScreen(nav, settings) }
        composable("game/{mode}/{slot}", arguments = listOf(navArgument("slot") { type = NavType.IntType })) { e ->
            GameScreen(Mode.of(e.arguments!!.getString("mode")!!), e.arguments!!.getInt("slot"), nav, settings)
        }
    }
}

@Composable
private fun BigButton(title: String, subtitle: String, onClick: () -> Unit, primary: Boolean = false) {
    val bg = if (primary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (primary) Color.White else MaterialTheme.colorScheme.onBackground
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(bg).clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text(title, color = fg, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = fg.copy(alpha = 0.8f), fontSize = 13.sp)
    }
}

@Composable
fun HomeScreen(nav: NavController) {
    val app = LocalContext.current.applicationContext as PanjkhaneApp
    val repo = app.repo
    val levels by repo.levelResults().collectAsState(initial = emptyList())
    val all by repo.allResults().collectAsState(initial = emptyList())
    var today by remember { mutableIntStateOf(0) }
    var pendingYesterday by remember { mutableStateOf(false) }
    var help by remember { mutableStateOf(false) }
    LaunchedEffect(all.size) {
        today = repo.today()
        pendingYesterday = repo.session(Mode.DAILY, today - 1) != null && repo.dailyResult(today - 1) == null
    }
    val done = levels.map { it.level }.toSet()
    val next = (1..Persian.LEVELS).firstOrNull { it !in done } ?: Persian.LEVELS
    val dailyDone = all.any { it.mode == "daily" && it.slot == today }

    ScreenScaffold("", onBack = null, actions = {
        TextButton(onClick = { help = true }) { Text("راهنما") }
        TextButton(onClick = { nav.navigate("stats") }) { Text("آمار") }
        TextButton(onClick = { nav.navigate("settings") }) { Text("تنظیمات") }
    }) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(8.dp))
            Text("پنج‌خانه", fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            Text("کلمه‌ی پنج‌حرفی را در شش تلاش پیدا کن", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center, fontSize = 15.sp)
            Spacer(Modifier.height(16.dp))
            BigButton(
                if (done.isEmpty()) "شروع بازی" else "ادامه از مرحله‌ی ${next.fa()}",
                "${done.size.fa()} مرحله از ${Persian.LEVELS.fa()} مرحله انجام شده",
                { nav.navigate("game/level/$next") }, primary = true
            )
            BigButton("همه‌ی مرحله‌ها", "نقشه‌ی ${Persian.LEVELS.fa()} مرحله", { nav.navigate("levels") })
            BigButton(
                "چالش روزانه", if (dailyDone) "امروز بازی شد؛ فردا کلمه‌ی تازه‌ای منتظر توست" else "هر روز یک کلمه‌ی تازه، برای همه یکسان",
                { if (today > 0) nav.navigate("game/daily/$today") }
            )
            if (pendingYesterday) BigButton("چالش دیروز نیمه‌کاره مانده", "تا نیمه‌شب امروز فرصت داری تمامش کنی", { nav.navigate("game/daily/${today - 1}") })
            BigButton("حالت بی‌پایان", "بدون ترتیب و بدون محدودیت؛ هر بار کلمه‌ی تازه", { nav.navigate("game/infinite/0") })
            Spacer(Modifier.height(16.dp))
        }
    }
    if (help) AlertDialog(
        onDismissRequest = { help = false },
        confirmButton = { TextButton(onClick = { help = false }) { Text("متوجه شدم") } },
        title = { Text("روش بازی") },
        text = {
            Text(
                "کلمه‌ی پنج‌حرفی پنهان را در شش تلاش حدس بزن. بعد از هر حدس، رنگ هر خانه نشان می‌دهد:\n\n" +
                    "سبز: حرف درست است و در جای درست قرار دارد.\n" +
                    "زرد: حرف در کلمه هست، اما جایش اینجا نیست.\n" +
                    "خاکستری: این حرف در کلمه نیست.\n\n" +
                    "برای هر مرحله می‌توانی از چراغ بالای صفحه کمک بگیری؛ تعداد راهنما محدود است."
            )
        }
    )
}

@Composable
fun LevelsScreen(nav: NavController) {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as PanjkhaneApp
    val results by app.repo.levelResults().collectAsState(initial = null)
    val state = rememberLazyGridState()
    var scrolled by remember { mutableStateOf(false) }
    var review by remember { mutableStateOf<Int?>(null) }
    val map = (results ?: emptyList()).associateBy { it.level }
    val next = (1..Persian.LEVELS).firstOrNull { it !in map } ?: Persian.LEVELS
    LaunchedEffect(results) {
        if (results != null && !scrolled) { scrolled = true; state.scrollToItem(maxOf(0, next - 1 - 10)) }
    }
    val colors = LocalGameColors.current
    ScreenScaffold("مرحله‌ها", onBack = { nav.popBackStack() }) {
        Text("${map.size.fa()} از ${Persian.LEVELS.fa()} مرحله انجام شده", modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(5), state = state, contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(Persian.LEVELS) { i ->
                val level = i + 1
                val r = map[level]
                val unlocked = level == 1 || (level - 1) in map
                val bg = when {
                    r != null -> colors.correct
                    level == next -> MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)
                    unlocked -> MaterialTheme.colorScheme.surfaceVariant
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                }
                Box(
                    Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp)).background(bg).clickable {
                        when {
                            r != null -> review = level
                            unlocked -> nav.navigate("game/level/$level")
                            else -> Toast.makeText(ctx, "اول مرحله‌ی قبل را تمام کن", Toast.LENGTH_SHORT).show()
                        }
                    },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(level.fa(), fontWeight = FontWeight.Bold, fontSize = 17.sp, color = if (r != null) Color.White else MaterialTheme.colorScheme.onBackground)
                        if (r != null) Text("${r.guesses.fa()} حدس", fontSize = 10.sp, color = Color.White)
                        else if (!unlocked) Text("🔒", fontSize = 11.sp)
                    }
                }
            }
        }
    }
    review?.let { level ->
        val r = map[level]
        if (r != null) AlertDialog(
            onDismissRequest = { review = null },
            title = { Text("مرحله‌ی ${level.fa()}") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    val ans = app.repo.lex.levelAnswers[level - 1]
                    Board(r.words.split(" ").filter { it.isNotEmpty() }, "", ans, emptyMap(), -1, 0, 38.dp, false)
                    Spacer(Modifier.height(8.dp))
                    Text("کلمه: $ans", fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = { TextButton(onClick = { review = null; nav.navigate("game/level/$level") }) { Text("بازی دوباره") } },
            dismissButton = { TextButton(onClick = { review = null }) { Text("بستن") } }
        )
    }
}

@Composable
fun StatsScreen(nav: NavController) {
    val app = LocalContext.current.applicationContext as PanjkhaneApp
    val all by app.repo.allResults().collectAsState(initial = emptyList())
    val levels by app.repo.levelResults().collectAsState(initial = emptyList())
    var today by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { today = app.repo.today() }
    val modes = listOf("level" to "مرحله‌ها", "daily" to "روزانه", "infinite" to "بی‌پایان")
    val st = computeStats(all.filter { it.mode == modes[tab].first }, modes[tab].first == "daily", today)
    ScreenScaffold("آمار", onBack = { nav.popBackStack() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                modes.forEachIndexed { i, (_, label) -> FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) }) }
            }
            if (tab == 0) Text("مرحله‌های انجام‌شده: ${levels.size.fa()} از ${Persian.LEVELS.fa()}", fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                StatBox("بازی", st.played.fa())
                StatBox("درصد برد", (if (st.played == 0) 0 else st.wins * 100 / st.played).fa() + "٪")
                StatBox("رکورد پیاپی", st.current.fa())
                StatBox("بهترین رکورد", st.best.fa())
            }
            st.bestGuess?.let { Text("کم‌ترین تعداد حدس برای یک برد: ${it.fa()}") }
            Text("توزیع بردها", fontWeight = FontWeight.Bold)
            val max = (st.dist.maxOrNull() ?: 0).coerceAtLeast(1)
            st.dist.forEachIndexed { i, n ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text((i + 1).fa(), modifier = Modifier.width(18.dp))
                    Box(
                        Modifier.fillMaxWidth(maxOf(0.08f, n.toFloat() / max)).height(24.dp).clip(RoundedCornerShape(4.dp))
                            .background(if (n > 0) LocalGameColors.current.correct else LocalGameColors.current.absent),
                        contentAlignment = Alignment.CenterStart
                    ) { Text(n.fa(), color = Color.White, modifier = Modifier.padding(horizontal = 8.dp), fontSize = 13.sp) }
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 11.sp)
    }
}

@Composable
fun SettingsScreen(nav: NavController, st: Settings) {
    val app = LocalContext.current.applicationContext as PanjkhaneApp
    val scope = rememberCoroutineScope()
    ScreenScaffold("تنظیمات", onBack = { nav.popBackStack() }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("پوسته", fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("خودکار", "روشن", "تیره").forEachIndexed { i, l ->
                    FilterChip(selected = st.theme == i, onClick = { scope.launch { app.settings.setTheme(i) } }, label = { Text(l) })
                }
            }
            SwitchRow("لرزش هنگام لمس کلید", st.haptics) { scope.launch { app.settings.setHaptics(it) } }
            SwitchRow("رنگ‌های مناسب کوررنگی (نارنجی و آبی)", st.colorBlind) { scope.launch { app.settings.setColorBlind(it) } }
            SwitchRow("نمایش دکمه‌ی راهنما (چراغ)", st.hints) { scope.launch { app.settings.setHints(it) } }
            SwitchRow("انیمیشن چرخش خانه‌ها", st.animations) { scope.launch { app.settings.setAnimations(it) } }
            SwitchRow("حدس آزاد (هر ترکیب پنج‌حرفی پذیرفته شود)", st.freeGuess) { scope.launch { app.settings.setFreeGuess(it) } }
            Text(
                "اگر «حدس آزاد» خاموش باشد، فقط کلمه‌هایی که در فهرست واژه‌های بازی هستند پذیرفته می‌شوند.",
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
