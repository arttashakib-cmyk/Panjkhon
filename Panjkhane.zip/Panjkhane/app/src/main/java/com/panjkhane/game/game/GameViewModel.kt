package com.panjkhane.game.game

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.panjkhane.game.PanjkhaneApp
import com.panjkhane.game.data.GameSession
import com.panjkhane.game.data.Mode
import com.panjkhane.game.engine.Persian
import com.panjkhane.game.engine.TileState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.updateAndGet
import kotlinx.coroutines.launch

enum class Status { PLAYING, WON, LOST }

data class GameUi(
    val loading: Boolean = true,
    val answer: String = "",
    val guesses: List<String> = emptyList(),
    val current: String = "",
    val status: Status = Status.PLAYING,
    val message: String? = null,
    val shake: Int = 0,
    val hints: Map<Int, Char> = emptyMap(),
    val hintsLeft: Int = 0,
    val keyboardRows: Int = 0,
    val animateRow: Int = -1,
    val showResult: Boolean = false,
    val readOnly: Boolean = false
) {
    val keyStates: Map<Char, TileState>
        get() {
            val map = HashMap<Char, TileState>()
            for (g in guesses.take(keyboardRows)) {
                val st = Persian.evaluate(g, answer)
                for (i in g.indices) {
                    val old = map[g[i]]
                    if (old == null || st[i].ordinal < old.ordinal) map[g[i]] = st[i]
                }
            }
            return map
        }
}

class GameViewModel(private val app: PanjkhaneApp, val mode: Mode, val slot: Int) : ViewModel() {
    private val repo = app.repo
    private val lex = repo.lex
    private val _ui = MutableStateFlow(GameUi())
    val ui: StateFlow<GameUi> = _ui
    private var hintPositions: List<Int> = emptyList()

    init { viewModelScope.launch { load() } }

    private fun hintLimit() = when (mode) { Mode.LEVEL -> 2; Mode.DAILY -> 1; Mode.INFINITE -> 3 }

    private suspend fun load() {
        hintPositions = emptyList()
        var readOnly = false
        val answer: String
        var session: GameSession? = null
        var finishedWords: List<String>? = null
        when (mode) {
            Mode.LEVEL -> {
                answer = lex.levelAnswers[slot - 1]
                session = repo.session(mode, slot) ?: repo.newSession(mode, slot, answer)
            }
            Mode.DAILY -> {
                answer = lex.pool[repo.dailyWordIndex(slot)]
                val done = repo.dailyResult(slot)
                if (done != null) {
                    readOnly = true
                    finishedWords = done.words.split(" ").filter { it.isNotEmpty() }
                } else {
                    session = repo.session(mode, slot) ?: repo.newSession(mode, slot, answer)
                }
            }
            Mode.INFINITE -> {
                session = repo.session(mode, 0) ?: repo.newInfiniteSession()
                answer = session.answer
            }
        }
        val guesses = finishedWords ?: session!!.guesses.split(" ").filter { it.isNotEmpty() }
        hintPositions = session?.hints?.split(",")?.mapNotNull { it.toIntOrNull() } ?: emptyList()
        val won = guesses.lastOrNull() == answer
        val status = when {
            won -> Status.WON
            readOnly -> Status.LOST
            else -> Status.PLAYING
        }
        val left = when (mode) {
            Mode.INFINITE -> hintLimit() - repo.infiniteHintsUsed()
            else -> hintLimit() - hintPositions.size
        }.coerceAtLeast(0)
        _ui.value = GameUi(
            loading = false, answer = answer, guesses = guesses, status = status,
            hints = hintPositions.associateWith { answer[it] }, hintsLeft = left,
            keyboardRows = guesses.size, readOnly = readOnly,
            message = if (readOnly) "چالش امروز را بازی کرده‌ای؛ چالش بعدی نیمه‌شب (به وقت ایران) باز می‌شود." else null
        )
    }

    private fun sessionOf(s: GameUi) =
        GameSession(mode.id, if (mode == Mode.INFINITE) 0 else slot, s.answer, s.guesses.joinToString(" "), hintPositions.joinToString(","))

    fun type(c: Char) {
        _ui.update { s ->
            if (s.loading || s.readOnly || s.status != Status.PLAYING || s.current.length >= Persian.WORD_LENGTH) s
            else s.copy(current = s.current + c, message = null)
        }
    }

    fun delete() {
        _ui.update { s ->
            if (s.loading || s.readOnly || s.status != Status.PLAYING || s.current.isEmpty()) s
            else s.copy(current = s.current.dropLast(1), message = null)
        }
    }

    fun clearMessage() { _ui.update { it.copy(message = null) } }
    fun dismissResult() { _ui.update { it.copy(showResult = false) } }

    fun submit() {
        val s = _ui.value
        if (s.loading || s.readOnly || s.status != Status.PLAYING) return
        viewModelScope.launch {
            val settings = app.settings.current()
            if (s.current.length < Persian.WORD_LENGTH) {
                _ui.update { it.copy(message = "کلمه باید پنج حرف باشد", shake = it.shake + 1) }
                return@launch
            }
            if (!lex.isValid(s.current, settings.freeGuess)) {
                _ui.update { it.copy(message = "این کلمه در فهرست واژه‌ها نیست", shake = it.shake + 1) }
                return@launch
            }
            val guesses = s.guesses + s.current
            val won = s.current == s.answer
            val lost = !won && guesses.size >= Persian.MAX_GUESSES
            val status = if (won) Status.WON else if (lost) Status.LOST else Status.PLAYING
            val next = s.copy(guesses = guesses, current = "", status = status, message = null, animateRow = guesses.size - 1)
            _ui.value = next
            if (status == Status.PLAYING) repo.saveSession(sessionOf(next))
            else repo.finish(mode, if (mode == Mode.INFINITE) 0 else slot, won, guesses)
            delay(if (settings.animations) 1500L else 0L)
            _ui.update { it.copy(keyboardRows = maxOf(it.keyboardRows, guesses.size)) }
            if (status != Status.PLAYING) {
                delay(350)
                _ui.update { it.copy(showResult = true) }
            }
        }
    }

    fun hint() {
        viewModelScope.launch {
            val s = _ui.value
            if (s.loading || s.readOnly || s.status != Status.PLAYING || s.hintsLeft <= 0) return@launch
            val known = (0 until Persian.WORD_LENGTH).filter { i -> s.guesses.any { it[i] == s.answer[i] } }.toSet()
            val candidates = (0 until Persian.WORD_LENGTH).filter { it !in known && it !in hintPositions }
            if (candidates.isEmpty()) {
                _ui.update { it.copy(message = "حرف تازه‌ای برای راهنمایی نمانده") }
                return@launch
            }
            hintPositions = hintPositions + candidates.random()
            if (mode == Mode.INFINITE) repo.useInfiniteHint()
            val updated = _ui.updateAndGet { it.copy(hints = hintPositions.associateWith { p -> it.answer[p] }, hintsLeft = it.hintsLeft - 1) }
            repo.saveSession(sessionOf(updated))
        }
    }

    /** برای «تلاش دوباره» در مرحله و «کلمه‌ی بعدی» در حالت بی‌پایان */
    fun restart() {
        viewModelScope.launch {
            _ui.value = GameUi()
            load()
        }
    }

    companion object {
        fun factory(app: PanjkhaneApp, mode: Mode, slot: Int) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = GameViewModel(app, mode, slot) as T
        }
    }
}
