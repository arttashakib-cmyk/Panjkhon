package com.panjkhane.game.engine

import android.content.Context

enum class TileState { CORRECT, PRESENT, ABSENT }

object Persian {
    const val WORD_LENGTH = 5
    const val MAX_GUESSES = 6
    const val LEVELS = 500

    /** ۳۳ حرف الفبای فارسی (آ جدا از ا). چینش کیبورد از همین ترتیب ساخته می‌شود؛ برای تغییر چینش فقط KEY_ROWS را عوض کن. */
    val ALPHABET: List<Char> = "آابپتثجچحخدذرزژسشصضطظعغفقکگلمنوهی".toList()
    val ALPHABET_SET: Set<Char> = ALPHABET.toSet()

    val KEY_ROWS: List<List<Char>> = run {
        var i = 0
        listOf(7, 7, 7, 6, 6).map { n -> ALPHABET.subList(i, i + n).also { i += n } }
    }

    fun normalize(input: String): String {
        val sb = StringBuilder()
        for (c in input) {
            when {
                c.isWhitespace() -> {}
                c == '\u200c' || c == '\u200d' || c == '\u200e' || c == '\u200f' || c == '\u0640' || c == '\u00AD' || c == '\uFEFF' -> {}
                c in '\u064B'..'\u065F' || c == '\u0670' -> {}
                c == '\u064A' || c == '\u0649' || c == '\u0626' -> sb.append('ی')
                c == '\u0643' -> sb.append('ک')
                c == '\u0629' || c == '\u06C0' -> sb.append('ه')
                c == '\u0623' || c == '\u0625' || c == '\u0671' -> sb.append('ا')
                c == '\u0624' -> sb.append('و')
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    fun isWord(w: String) = w.length == WORD_LENGTH && w.all { it in ALPHABET_SET }

    fun evaluate(guess: String, answer: String): List<TileState> {
        val res = Array(guess.length) { TileState.ABSENT }
        val remaining = HashMap<Char, Int>()
        for (i in answer.indices) {
            if (i < guess.length && guess[i] == answer[i]) res[i] = TileState.CORRECT
            else remaining[answer[i]] = (remaining[answer[i]] ?: 0) + 1
        }
        for (i in guess.indices) {
            if (res[i] != TileState.CORRECT) {
                val n = remaining[guess[i]] ?: 0
                if (n > 0) { res[i] = TileState.PRESENT; remaining[guess[i]] = n - 1 }
            }
        }
        return res.toList()
    }
}

class Lexicon(context: Context) {
    val levelAnswers: List<String> = read(context, "answers_levels.txt")
    /** مجموعه‌ی پاسخ‌های ممکن برای روزانه و بی‌پایان؛ ترتیبش هرگز نباید عوض شود (فقط به انتها اضافه شود). */
    val pool: List<String> = levelAnswers + read(context, "answers_extra.txt")
    private val valid: Set<String> = (pool + read(context, "guesses.txt")).toHashSet()

    init { check(levelAnswers.size == Persian.LEVELS) { "answers_levels must have ${Persian.LEVELS} words" } }

    fun isValid(word: String, free: Boolean): Boolean =
        Persian.isWord(word) && (free || word in valid)

    private fun read(context: Context, name: String): List<String> =
        context.assets.open(name).bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.map { Persian.normalize(it) }.filter { Persian.isWord(it) }.toList()
        }
}
